// whisper.js - Whisper 語音辨識服務
// TODO: 串接 OpenAI Whisper API 或本地模型
async function transcribeAudio(audioBuffer) {
  // stub: 假回傳
  return '這是語音辨識結果（假資料）';
}

module.exports = { transcribeAudio };
