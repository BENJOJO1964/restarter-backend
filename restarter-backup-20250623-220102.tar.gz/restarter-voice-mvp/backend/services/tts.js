// tts.js - TTS 語音合成服務
// TODO: 串接 ElevenLabs 或 OpenAI TTS，支援流式語音

module.exports = {};
