// vad.js - 語音活動偵測（Voice Activity Detection）模組
// TODO: 實作 VAD，偵測語音流中的說話/靜音區段

module.exports = {};
