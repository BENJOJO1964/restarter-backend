// server.js - WebSocket + REST API 入口
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// WebSocket 連線管理
wss.on('connection', (ws) => {
  console.log('Client connected');
  ws.on('message', (msg) => {
    // 處理音訊流、控制訊息
  });
  ws.on('close', () => console.log('Client disconnected'));
});

// REST API 路由（Whisper, GPT, TTS）
const ttsRoutes = require('./routes/tts');
const gptRoutes = require('./routes/gpt');
const whisperRoutes = require('./routes/whisper');
const quotesRoutes = require('./routes/quotes');
const coachRoutes = require('./routes/coaching');
const scenariosRouter = require('./routes/scenarios');

app.use('/api/tts', ttsRoutes);
app.use('/api/gpt', gptRoutes);
app.use('/api/whisper', whisperRoutes);
app.use('/api/quotes', quotesRoutes);
app.use('/api/coach', coachRoutes);
app.use('/api/scenarios', scenariosRouter);

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../frontend/dist')));

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

app.get('/health', (req, res) => {
  res.send({
    // ... existing code ...
  });
});
