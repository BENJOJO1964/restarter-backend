import React from 'react';
import { useVAD } from '../hooks/useVAD';

export default function AudioRecorder({ onAudio }: { onAudio: (audio: Blob) => void }) {
  const { isListening, startListening, stopListening } = useVAD({
    onSpeechEnd: (audio) => {
      onAudio(audio);
    },
  });

  const handleButtonClick = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  return (
    <div>
      <button 
        onClick={handleButtonClick}
        style={{
          padding: '10px 20px',
          fontSize: '16px',
          cursor: 'pointer',
          border: isListening ? '2px solid #ff4136' : '2px solid #0074D9',
          backgroundColor: isListening ? '#ff4136' : '#0074D9',
          color: 'white',
          borderRadius: '8px',
          fontWeight: 'bold',
        }}
      >
        {isListening ? '處理中...' : '開始說話'}
      </button>
    </div>
  );
}
