// App.tsx - Restart Voice MVP 入口
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import Home from './pages/Home';
import RestartWall from './pages/RestartWall';
import ChatCompanion from './pages/ChatCompanion';
import RegisterPage from './pages/RegisterPage';
import FriendMatch from './pages/FriendMatch';
import InboxPage from './pages/InboxPage';
import AIStyleReply from './pages/AIStyleReply';
import RealisticTTS from './pages/RealisticTTS';
import EmotionVisualLab from './pages/EmotionVisualLab';
import Missions from './pages/Missions';
import PairTalk from './pages/PairTalk';
import SkillBox from './pages/SkillBox';
import PairTalkMatch from './pages/PairTalkMatch';
import WhackAMole from './pages/WhackAMole';
import TermsPage from './pages/TermsPage';
import PracticePage from './pages/PracticePage';
import './modern.css';
import app from './src/firebaseConfig';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { VideoReactionProvider } from './components/VideoReactionContext';
import { UserStatusProvider } from './hooks/useUserStatus';
import { MicStatusProvider, useMicStatus } from './components/MicStatusContext';
import WebSocketProvider from './components/WebSocketProvider';

function MicIndicator() {
  const { isMicOn } = useMicStatus();
  if (!isMicOn) return null;

  return (
    <div style={{
        position: 'fixed',
        top: '12px',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 9999,
        background: '#ff6347', // Orange-Red color
        borderRadius: '50%',
        padding: '12px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 4px 20px rgba(0,0,0,0.35)',
        border: '2px solid white',
    }}>
        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="white">
            <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.49 6-3.31 6-6.72h-1.7z"/>
        </svg>
    </div>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [auth]);

  if (loading) {
    return <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', fontSize: '2rem' }}>Loading...</div>;
  }

  return (
    <MicStatusProvider>
      <WebSocketProvider>
        <VideoReactionProvider>
          <BrowserRouter>
            <MicIndicator />
            <UserStatusProvider>
              <Routes>
                <Route path="/terms" element={<TermsPage />} />
                <Route path="/" element={user ? <Home /> : <RegisterPage />} />
                {user && <Route path="/wall" element={<RestartWall />} />}
                {user && <Route path="/chat" element={<ChatCompanion />} />}
                {user && <Route path="/friend" element={<FriendMatch />} />}
                {user && <Route path="/inbox" element={<InboxPage />} />}
                {user && <Route path="/ai" element={<AIStyleReply />} />}
                {user && <Route path="/tts" element={<RealisticTTS />} />}
                {user && <Route path="/journal" element={<EmotionVisualLab />} />}
                {user && <Route path="/missions" element={<Missions />} />}
                {user && <Route path="/pairtalk" element={<PairTalk />} />}
                {user && <Route path="/skillbox" element={<SkillBox />} />}
                {user && <Route path="/skillbox/:scenarioId" element={<PracticePage />} />}
              </Routes>
            </UserStatusProvider>
          </BrowserRouter>
        </VideoReactionProvider>
      </WebSocketProvider>
    </MicStatusProvider>
  );
}

export default App;
