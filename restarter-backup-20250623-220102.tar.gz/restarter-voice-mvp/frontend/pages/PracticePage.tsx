import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getAuth, signOut } from 'firebase/auth';
import AudioRecorder from '../components/AudioRecorder';
import { Scenario } from './SkillBox';

type LanguageCode = 'zh-TW' | 'zh-CN' | 'en' | 'ja' | 'ko' | 'th' | 'vi' | 'ms' | 'la';

const LANGS: { code: LanguageCode; label: string }[] = [
    { code: 'zh-TW', label: '繁中' },
    { code: 'zh-CN', label: '简中' },
    { code: 'en', label: 'EN' },
    { code: 'ja', label: '日本語' },
    { code: 'ko', label: '한국어' },
    { code: 'th', label: 'ภาษาไทย' },
    { code: 'vi', label: 'Tiếng Việt' },
    { code: 'ms', label: 'Bahasa Melayu' },
    { code: 'la', label: 'Latīna' },
];

const UI_TEXT = {
    backToScenarios: { 'zh-TW': '← 返回情境列表', 'zh-CN': '← 返回情境列表', 'ja': '← シナリオ一覧へ戻る', 'en': '← Back to Scenarios', 'ko': '← 시나리오 목록으로', 'th': '← กลับไปที่รายการสถานการณ์', 'vi': '← Quay lại danh sách kịch bản', 'ms': '← Kembali ke Senarai Senario', 'la': '← Ad indicem scaenariorum redire' },
    logout: { 'zh-TW': '登出', 'zh-CN': '登出', 'ja': 'ログアウト', 'en': 'Logout', 'ko': '로그아웃', 'th': 'ออกจากระบบ', 'vi': 'Đăng xuất', 'ms': 'Log keluar', 'la': 'Exire' },
    practiceRoom: { 'zh-TW': '模擬練習中', 'zh-CN': '模拟练习中', 'ja': '練習シミュレーション中', 'en': 'Practice in Progress', 'ko': '연습 시뮬레이션 중', 'th': 'กำลังฝึกซ้อม', 'vi': 'Đang thực hành', 'ms': 'Latihan Sedang Berlangsung', 'la': 'In Exercitatione' },
    yourTurn: { 'zh-TW': '換你說了', 'zh-CN': '换你说了', 'ja': 'あなたの番です', 'en': 'Your turn', 'ko': '당신 차례입니다', 'th': 'ตาคุณแล้ว', 'vi': 'Đến lượt bạn', 'ms': 'Giliran anda', 'la': 'Tua vice est' },
    recording: { 'zh-TW': '錄音中...', 'zh-CN': '录音中...', 'ja': '録音中...', 'en': 'Recording...', 'ko': '녹음 중...', 'th': 'กำลังบันทึก...', 'vi': 'Đang ghi âm...', 'ms': 'Merakam...', 'la': 'Registrans...' },
    send: { 'zh-TW': '傳送', 'zh-CN': '发送', 'ja': '送信', 'en': 'Send', 'ko': '보내기', 'th': 'ส่ง', 'vi': 'Gửi', 'ms': 'Hantar', 'la': 'Mitte' },
};

export default function PracticePage() {
    const navigate = useNavigate();
    const { scenarioId } = useParams();
    const auth = getAuth();
    const lang = (localStorage.getItem('lang') as LanguageCode) || 'zh-TW';
    
    const [scenario, setScenario] = useState<Scenario | null>(null);
    const [messages, setMessages] = useState<any[]>([]);
    const [userText, setUserText] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const audioRef = useRef<HTMLAudioElement>(null);

    useEffect(() => {
        const fetchScenarioDetails = async () => {
            setIsLoading(true);
            try {
                const response = await fetch(`/api/scenarios?lang=${lang}`);
                if (!response.ok) throw new Error('Failed to fetch scenarios');
                const scenarios: Scenario[] = await response.json();
                const currentScenario = scenarios.find(s => s.id === parseInt(scenarioId || ''));
                
                if (currentScenario) {
                    setScenario(currentScenario);
                    setMessages([{ sender: 'ai', text: currentScenario.initialPrompt }]);
                } else {
                    setScenario(null);
                }

            } catch (error) {
                console.error("Error fetching scenario details:", error);
                setScenario(null);
            } finally {
                setIsLoading(false);
            }
        };

        if (scenarioId) {
            fetchScenarioDetails();
        }
    }, [scenarioId, lang]);

    const callApi = async (url: string, body: any, options: any = {}) => {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            ...options
        });
        if (!res.ok) throw new Error('API call failed');
        return res;
    };

    const handleAudio = async (audioBlob: Blob) => {
        setIsLoading(true);
        try {
            const formData = new FormData();
            formData.append('audio', audioBlob, 'audio.webm');
            
            const res = await fetch('/api/whisper', { method: 'POST', body: formData });
            if (!res.ok) {
                const errorText = await res.text();
                throw new Error(`Whisper API failed: ${errorText}`);
            }
            const { transcript } = await res.json();
            
            if (transcript) {
                const newMessages = [...messages, { sender: 'user', text: transcript }];
                setMessages(newMessages);
                getAIResponse(newMessages);
            }
        } catch (error) {
            console.error("Error with audio processing:", error);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleSendText = () => {
        if (!userText.trim() || isLoading) return;
        const newMessages = [...messages, { sender: 'user', text: userText }];
        setMessages(newMessages);
        setUserText('');
        getAIResponse(newMessages);
    };

    const getAIResponse = async (currentMessages: any[]) => {
        setIsLoading(true);
        try {
            const res = await callApi('/api/gpt', { messages: currentMessages });
            const { message } = await res.json();
            setMessages(prev => [...prev, { sender: 'ai', text: message }]);
            
            const ttsRes = await callApi('/api/tts', { text: message }, { responseType: 'blob' });
            const audioBlob = await ttsRes.blob();
            if (audioRef.current) {
                audioRef.current.src = URL.createObjectURL(audioBlob);
                audioRef.current.play();
            }

        } catch (error) {
            console.error("Error getting AI response:", error);
            setMessages(prev => [...prev, { sender: 'ai', text: '抱歉，我現在遇到一些問題，請稍後再試。' }]);
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) {
        return <div>Loading...</div>;
    }

    if (!scenario) {
        return <div>Scenario not found. <button onClick={() => navigate('/skillbox')}>Go back</button></div>;
    }

    return (
        <div className="modern-bg" style={{ background: `url('/snowmountin.png') center center / cover no-repeat`, minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <audio ref={audioRef} hidden />
            {/* Top Bar */}
            <div style={{ width: '100%', position: 'absolute', top: 0, left: 0, zIndex: 100, display: 'flex', justifyContent: 'space-between', padding: '18px 32px 0 32px' }}>
                <button className="topbar-btn" onClick={() => navigate('/skillbox')} style={{ fontWeight: 700, fontSize: 18, padding: '6px 16px', borderRadius: 8, border: '1.5px solid #6B5BFF', background: '#fff', color: '#6B5BFF', cursor: 'pointer' }}>{UI_TEXT.backToScenarios[lang]}</button>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <button className="topbar-btn" onClick={async () => { await signOut(auth); localStorage.clear(); window.location.href = '/' }} style={{ fontWeight: 700, fontSize: 18, padding: '6px 16px', borderRadius: 8, border: '1.5px solid #6B5BFF', background: '#fff', color: '#6B5BFF', cursor: 'pointer' }}>{UI_TEXT.logout[lang]}</button>
                    <select className="topbar-select" value={lang} onChange={e => { localStorage.setItem('lang', e.target.value as LanguageCode); window.location.reload(); }} style={{ padding: '6px 14px', borderRadius: 8, fontWeight: 600, border: '1.5px solid #6B5BFF', color: '#6B5BFF', background: '#fff' }}>
                        {LANGS.map(l => <option key={l.code} value={l.code}>{l.label}</option>)}
                    </select>
                </div>
            </div>

            {/* Main Content */}
            <div style={{ width: '100%', maxWidth: 700, background: 'rgba(255, 255, 255, 0.9)', borderRadius: 16, padding: '24px 32px', boxShadow: '0 4px 24px #0002', display: 'flex', flexDirection: 'column', marginTop: '80px' }}>
                <h2 style={{ fontSize: '2rem', fontWeight: 900, color: '#6B5BFF', textAlign: 'center', margin: '0 0 8px 0' }}>{scenario.title}</h2>
                <p style={{ fontSize: 16, color: '#4A4A4A', textAlign: 'center', margin: '0 0 24px 0' }}>{scenario.description}</p>
                
                {/* Chat Area */}
                <div style={{ height: '40vh', overflowY: 'auto', background: '#f0f0f5', borderRadius: 12, padding: 16, marginBottom: 24, display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {messages.map((msg, index) => (
                        <div key={index} style={{ alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start', maxWidth: '75%' }}>
                            <div style={{
                                background: msg.sender === 'user' ? '#6B5BFF' : '#fff',
                                color: msg.sender === 'user' ? '#fff' : '#4A4A4A',
                                padding: '10px 16px',
                                borderRadius: '18px',
                                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                            }}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Input Area */}
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                    <AudioRecorder onAudio={handleAudio} />
                    <input 
                        type="text"
                        value={userText}
                        onChange={(e) => setUserText(e.target.value)}
                        placeholder={isLoading ? "AI正在思考..." : UI_TEXT.yourTurn[lang]}
                        disabled={isLoading}
                        style={{ flex: 1, padding: '12px 16px', borderRadius: 12, border: '2px solid #ddd', fontSize: 16, outline: 'none', background: isLoading ? '#f0f0f0' : '#fff' }}
                        onKeyDown={(e) => e.key === 'Enter' && handleSendText()}
                    />
                    <button onClick={handleSendText} disabled={isLoading} style={{ padding: '12px 24px', borderRadius: 12, background: isLoading ? '#ccc' : '#6B5BFF', color: '#fff', border: 'none', fontWeight: 700, fontSize: 16, cursor: isLoading ? 'not-allowed' : 'pointer' }}>
                        {isLoading ? "..." : UI_TEXT.send[lang]}
                    </button>
                </div>
            </div>
        </div>
    );
} 