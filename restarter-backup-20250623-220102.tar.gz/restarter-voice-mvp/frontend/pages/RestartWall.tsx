import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { formatWithTone } from '../utils/toneFormatter';
import type { Tone, Quote } from '../../shared/types';
import { getAuth } from 'firebase/auth';

type LanguageCode = 'zh-TW' | 'zh-CN' | 'en' | 'ja' | 'ko' | 'vi' | 'th' | 'la' | 'ms';

const LANGS: { code: LanguageCode; label: string }[] = [
  { code: 'zh-TW', label: '繁中' },
  { code: 'zh-CN', label: '简中' },
  { code: 'en', label: 'EN' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'vi', label: 'Tiếng Việt' },
  { code: 'th', label: 'ไทย' },
  { code: 'la', label: 'Latina' },
  { code: 'ms', label: 'Bahasa Melayu' },
];

const TEXTS: Record<LanguageCode, any> = {
  'zh-TW': {
    back: '← 返回首頁',
    logout: '登出',
    title: '🧱 情緒牆 Restart Wall',
    inbox: '💌 我的留言箱',
    placeholder: '說出你的心聲... (可語音輸入)',
    send: '發送',
    sending: '發送中...',
    noMessages: '還沒有留言，快來發表你的心聲吧！',
    commentsTitle: '留言互動：',
    noComments: '還沒有人留言',
    modalTitle: '這是他的心情貼文：',
    modalAction: '留言給他：',
    nicknamePlaceholder: '你的暱稱',
    commentPlaceholder: '留言內容...',
    submitComment: '送出留言',
    gentle: '溫柔',
    hopeful: '希望',
    gentleDesc: '溫柔、體貼、安撫人心',
    hopefulDesc: '充滿希望、鼓勵、正向',
    aiPrefix: 'AI安慰：',
  },
  'zh-CN': {
    back: '← 返回首页',
    logout: '登出',
    title: '🧱 情绪墙 Restart Wall',
    inbox: '💌 我的留言箱',
    placeholder: '说出你的心声... (可语音输入)',
    send: '发送',
    sending: '发送中...',
    noMessages: '还没有留言，快来发表你的心声吧！',
    commentsTitle: '留言互动：',
    noComments: '还没有人留言',
    modalTitle: '这是他的心情贴文：',
    modalAction: '留言给他：',
    nicknamePlaceholder: '你的昵称',
    commentPlaceholder: '留言内容...',
    submitComment: '送出留言',
    gentle: '温柔',
    hopeful: '希望',
    gentleDesc: '温柔、体贴、安抚人心',
    hopefulDesc: '充满希望、鼓励、正向',
    aiPrefix: 'AI安慰：',
  },
  'en': {
    back: '← Back to Home',
    logout: 'Logout',
    title: '🧱 Emotion Wall Restart Wall',
    inbox: '💌 My Inbox',
    placeholder: 'Say what you feel... (voice input available)',
    send: 'Send',
    sending: 'Sending...',
    noMessages: 'No messages yet. Come and share your feelings!',
    commentsTitle: 'Comments:',
    noComments: 'No comments yet',
    modalTitle: "Here's their post:",
    modalAction: 'Leave a comment:',
    nicknamePlaceholder: 'Your Nickname',
    commentPlaceholder: 'Comment content...',
    submitComment: 'Submit Comment',
    gentle: 'Gentle',
    hopeful: 'Hopeful',
    gentleDesc: 'Gentle, considerate, and comforting.',
    hopefulDesc: 'Full of hope, encouragement, and positivity.',
    aiPrefix: 'AI Comfort: ',
  },
  'ja': {
    back: '← ホームに戻る',
    logout: 'ログアウト',
    title: '🧱 感情の壁 Restart Wall',
    inbox: '💌 私の受信箱',
    placeholder: 'あなたの気持ちを話して...(音声入力可)',
    send: '送信',
    sending: '送信中...',
    noMessages: 'まだメッセージはありません。あなたの気持ちを投稿しに来てください！',
    commentsTitle: 'コメント：',
    noComments: 'まだコメントはありません',
    modalTitle: '彼の投稿です：',
    modalAction: '彼にコメントする：',
    nicknamePlaceholder: 'あなたのニックネーム',
    commentPlaceholder: 'コメント内容...',
    submitComment: 'コメントを送信',
    gentle: '優しい',
    hopeful: '希望',
    gentleDesc: '優しく、思いやりがあり、心を癒す',
    hopefulDesc: '希望に満ち、励まし、ポジティブ',
    aiPrefix: 'AIの慰め：',
  },
    'ko': {
    back: '← 홈으로 돌아가기',
    logout: '로그아웃',
    title: '🧱 감정의 벽 Restart Wall',
    inbox: '💌 내 메시지함',
    placeholder: '당신의 마음을 말해보세요... (음성 입력 가능)',
    send: '전송',
    sending: '전송 중...',
    noMessages: '아직 메시지가 없습니다. 와서 당신의 마음을 표현하세요!',
    commentsTitle: '댓글:',
    noComments: '아직 댓글이 없습니다',
    modalTitle: '그의 게시물입니다:',
    modalAction: '그에게 댓글 남기기:',
    nicknamePlaceholder: '닉네임',
    commentPlaceholder: '댓글 내용...',
    submitComment: '댓글 보내기',
    gentle: '온화함',
    hopeful: '희망',
    gentleDesc: '부드럽고, 사려 깊고, 위로가 되는',
    hopefulDesc: '희망차고, 격려하며, 긍정적인',
    aiPrefix: 'AI 위로: ',
  },
  'vi': {
    back: '← Quay lại Trang chủ',
    logout: 'Đăng xuất',
    title: '🧱 Bức tường Cảm xúc Restart Wall',
    inbox: '💌 Hộp thư của tôi',
    placeholder: 'Nói ra cảm xúc của bạn... (có thể nhập bằng giọng nói)',
    send: 'Gửi',
    sending: 'Đang gửi...',
    noMessages: 'Chưa có tin nhắn nào. Hãy đến và chia sẻ cảm xúc của bạn!',
    commentsTitle: 'Bình luận:',
    noComments: 'Chưa có bình luận nào',
    modalTitle: 'Đây là bài đăng của họ:',
    modalAction: 'Để lại bình luận:',
    nicknamePlaceholder: 'Biệt danh của bạn',
    commentPlaceholder: 'Nội dung bình luận...',
    submitComment: 'Gửi bình luận',
    gentle: 'Nhẹ nhàng',
    hopeful: 'Hy vọng',
    gentleDesc: 'Nhẹ nhàng, chu đáo và an ủi.',
    hopefulDesc: 'Tràn đầy hy vọng, khích lệ và tích cực.',
    aiPrefix: 'AI an ủi: ',
  },
  'th': {
    back: '← กลับไปหน้าแรก',
    logout: 'ออกจากระบบ',
    title: '🧱 กำแพงอารมณ์ Restart Wall',
    inbox: '💌 กล่องข้อความของฉัน',
    placeholder: 'บอกความรู้สึกของคุณ... (สามารถป้อนด้วยเสียงได้)',
    send: 'ส่ง',
    sending: 'กำลังส่ง...',
    noMessages: 'ยังไม่มีข้อความ มาแบ่งปันความรู้สึกของคุณสิ!',
    commentsTitle: 'ความคิดเห็น:',
    noComments: 'ยังไม่มีความคิดเห็น',
    modalTitle: 'นี่คือโพสต์ของพวกเขา:',
    modalAction: 'แสดงความคิดเห็น:',
    nicknamePlaceholder: 'ชื่อเล่นของคุณ',
    commentPlaceholder: 'เนื้อหาความคิดเห็น...',
    submitComment: 'ส่งความคิดเห็น',
    gentle: 'อ่อนโยน',
    hopeful: 'ความหวัง',
    gentleDesc: 'อ่อนโยน, เอาใจใส่, และปลอบโยน',
    hopefulDesc: 'เต็มไปด้วยความหวัง, การให้กำลังใจ, และแง่บวก',
    aiPrefix: 'AI ปลอบใจ: ',
  },
  'la': {
    back: '← Ad Domum Redire',
    logout: 'Exire',
    title: '🧱 Murus Emotionum Restart Wall',
    inbox: '💌 Cista Mea',
    placeholder: 'Dic quod sentis... (vox initus praesto est)',
    send: 'Mittere',
    sending: 'Mittens...',
    noMessages: 'Nullae epistulae adhuc. Veni et communica sensus tuos!',
    commentsTitle: 'Commentarii:',
    noComments: 'Nulli commentarii adhuc',
    modalTitle: 'Ecce nuntius eorum:',
    modalAction: 'Mitte commentarium:',
    nicknamePlaceholder: 'Tuum agnomen',
    commentPlaceholder: 'Contentum commentarii...',
    submitComment: 'Mitte Commentarium',
    gentle: 'Mitis',
    hopeful: 'Spei Plenus',
    gentleDesc: 'Mitis, consideratus, et consolans.',
    hopefulDesc: 'Plenus spei, cohortationis, et positivitatis.',
    aiPrefix: 'AI Solamen: ',
  },
  'ms': {
    back: '← Kembali ke Laman Utama',
    logout: 'Log keluar',
    title: '🧱 Dinding Emosi Restart Wall',
    inbox: '💌 Peti Masuk Saya',
    placeholder: 'Luahkan perasaan anda... (input suara tersedia)',
    send: 'Hantar',
    sending: 'Menghantar...',
    noMessages: 'Belum ada mesej. Ayuh kongsikan perasaan anda!',
    commentsTitle: 'Komen:',
    noComments: 'Belum ada komen',
    modalTitle: 'Ini kiriman mereka:',
    modalAction: 'Tinggalkan komen:',
    nicknamePlaceholder: 'Nama Samaran Anda',
    commentPlaceholder: 'Kandungan komen...',
    submitComment: 'Hantar Komen',
    gentle: 'Lembut',
    hopeful: 'Harapan',
    gentleDesc: 'Lembut, bertimbang rasa, dan menenangkan.',
    hopefulDesc: 'Penuh harapan, galakan, dan positif.',
    aiPrefix: 'AI Pujukan: ',
  },
};

interface Message {
  id: string;
  text: string;
  aiReply: string;
  toneId: string;
  createdAt: string;
  user: {
    id: string;
    name: string;
    avatar: string;
    country: string;
    region: string;
    email: string;
  };
  comments?: { nickname: string; content: string; toUserId: string; }[];
}

const AVATAR_LIST = [
  '/avatars/male1.jpg', '/avatars/female1.jpg', '/avatars/male2.jpg', '/avatars/female2.jpg',
  '/avatars/male3.jpg', '/avatars/female3.jpg', '/avatars/male4.jpg', '/avatars/female4.jpg',
];

function randomAvatar() {
  return AVATAR_LIST[Math.floor(Math.random() * AVATAR_LIST.length)];
}

function randomName() {
  const names = ['小明', '小美', 'John', 'Alice', 'Yuki', 'Tom', 'Mia', 'Ken'];
  return names[Math.floor(Math.random() * names.length)];
}

function randomCountry() {
  const arr = ['台灣', '日本', '美國', '香港', '韓國', '新加坡'];
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomRegion() {
  const arr = ['台北', '東京', '舊金山', '首爾', '新加坡', '高雄'];
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomEmail(name: string) {
  return name.toLowerCase() + '@demo.com';
}

export default function RestartWall() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [showUser, setShowUser] = useState<null|Message>(null);
  const [commentInput, setCommentInput] = useState('');
  const [commentNickname, setCommentNickname] = useState('');
  const [lang, setLang] = useState<LanguageCode>(() => (localStorage.getItem('lang') as LanguageCode) || 'zh-TW');
  const t = TEXTS[lang] || TEXTS['zh-TW'];

  const demoTones: Tone[] = [
    { id: 'gentle', name: t.gentle, description: t.gentleDesc, stylePrompt: '請用溫柔、體貼的語氣回應。' },
    { id: 'hopeful', name: t.hopeful, description: t.hopefulDesc, stylePrompt: '請用充滿希望、鼓勵的語氣回應。' },
  ];
  const [selectedTone, setSelectedTone] = useState<Tone>(demoTones[0]);

  // 取得當前登入者 userId
  useEffect(() => {
    try {
      const auth = getAuth();
      const user = auth.currentUser;
      if (user) {
        localStorage.setItem('userId', user.displayName || user.email || '');
      }
    } catch {}
  }, []);

  // 假 AI 回覆
  const fakeAIReply = (text: string, tone: Tone) => `${formatWithTone(t.aiPrefix + text, tone.name)}`;

  const handleSend = async () => {
    if (!input.trim()) return;
    setLoading(true);
    const name = randomName();
    const userMsg: Message = {
      id: Date.now().toString(),
      text: input,
      aiReply: '',
      toneId: selectedTone.id,
      createdAt: new Date().toISOString(),
      user: {
        id: name,
        name,
        avatar: randomAvatar(),
        country: randomCountry(),
        region: randomRegion(),
        email: randomEmail(name),
      },
      comments: [],
    };
    setMessages([userMsg, ...messages]);
    setInput('');
    setTimeout(() => {
      setMessages(prev => {
        const newMsgs = prev.map(m => m.id === userMsg.id ? { ...m, aiReply: fakeAIReply(m.text, selectedTone) } : m);
        localStorage.setItem('messages', JSON.stringify(newMsgs));
        return newMsgs;
      });
      setLoading(false);
    }, 1200);
  };

  const handleAddComment = (msg: Message) => {
    if (!commentInput.trim() || !commentNickname.trim()) return;
    setMessages(msgs => {
      const newMsgs = msgs.map(m => m.id === msg.id ? { ...m, comments: [...(m.comments||[]), { nickname: commentNickname, content: commentInput, toUserId: msg.user.id }] } : m);
      localStorage.setItem('messages', JSON.stringify(newMsgs));
      return newMsgs;
    });
    setCommentInput('');
    setCommentNickname('');
    setShowUser(null);
  };

  return (
    <div className="modern-bg" style={{ background: `url('/snowmountain.png') center center / cover no-repeat`, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{position:'absolute',top:0,left:0,width:'100%',zIndex:100,display:'flex',justifyContent:'space-between',alignItems:'center',padding:'18px 32px 0 32px',boxSizing:'border-box',background:'transparent'}}>
        <button onClick={()=>navigate('/')} style={{background:'none',border:'none',color:'#6c63ff',fontWeight:700,fontSize:18,cursor:'pointer'}}>{t.back}</button>
        <div style={{display:'flex',gap:12,marginRight:8}}>
          <button className="topbar-btn" onClick={async()=>{const auth=getAuth();await auth.signOut();localStorage.clear();window.location.href='/'}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='';e.currentTarget.style.color='';}}>{t.logout}</button>
          <select className="topbar-select" value={lang} onChange={e=>{const newLang = e.target.value as LanguageCode; setLang(newLang); localStorage.setItem('lang', newLang);}} style={{padding:'6px 14px',borderRadius:8,fontWeight:600,cursor:'pointer'}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='';e.currentTarget.style.color='';}}>
            {LANGS.map(l => <option key={l.code} value={l.code}>{l.label}</option>)}
          </select>
        </div>
      </div>
      <div className="modern-container" style={{ maxWidth: 600, width: '100%', margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
          <button onClick={() => navigate('/')} style={{ background: 'none', border: 'none', color: '#6c63ff', fontWeight: 700, fontSize: 18, cursor: 'pointer', marginRight: 12 }}>{t.back}</button>
          <h2 className="modern-title" style={{ fontSize: '2.2rem', margin: 0, flex: 1, textAlign: 'center', color:'#6B5BFF', textShadow:'0 2px 12px #6B5BFF88, 0 4px 24px #0008', letterSpacing:1, display:'flex',alignItems:'center',gap:8 }}>{t.title}</h2>
          <button onClick={() => navigate('/inbox')} style={{ background: 'linear-gradient(135deg, #6B5BFF 60%, #23c6e6 100%)', color: '#fff', border: 'none', borderRadius: 12, fontWeight: 900, fontSize: 17, padding: '10px 28px', marginLeft: 18, boxShadow: '0 2px 12px #6B5BFF33', letterSpacing: 2 }}>{t.inbox}</button>
        </div>
        <div className="tone-list" style={{ marginBottom: 18 }}>
          {demoTones.map(tone => (
            <div
              key={tone.id}
              className={`tone-card${selectedTone.id === tone.id ? ' selected' : ''}`}
              onClick={() => setSelectedTone(tone)}
            >
              <div className="tone-name">{tone.name}</div>
              <div className="tone-desc">{tone.description}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 12, marginBottom: 18 }}>
          <input
            className="quote-card"
            style={{ flex: 1, fontSize: 18, padding: '12px 16px', border: 'none', outline: 'none', background: '#232946', color: '#fff' }}
            placeholder={t.placeholder}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            disabled={loading}
          />
          <button
            className="tone-card selected"
            style={{ fontSize: 18, padding: '12px 24px' }}
            onClick={handleSend}
            disabled={loading}
          >
            {loading ? t.sending : t.send}
          </button>
        </div>
        <div className="quote-list">
          {messages.length === 0 && <div style={{ color: '#614425', textAlign: 'center', marginTop: 32 }}>{t.noMessages}</div>}
          {messages.map(msg => (
            <div key={msg.id} className="quote-card" style={{ position: 'relative', paddingLeft: 64 }}>
              <img src={msg.user.avatar} alt="avatar" style={{ width: 48, height: 48, borderRadius: '50%', objectFit: 'cover', position: 'absolute', left: 8, top: 16, cursor: 'pointer', border: '2px solid #6B5BFF' }} onClick={() => setShowUser(msg)} />
              <div className="quote-text">{msg.text}</div>
              <div className="quote-tone">({msg.toneId})</div>
              {msg.aiReply && <div className="quote-tone-style">{msg.aiReply}</div>}
              <div style={{ fontSize: 12, color: '#614425', marginTop: 6 }}>{new Date(msg.createdAt).toLocaleString()}</div>
              <div style={{ marginTop: 14, background: '#f7f7ff', borderRadius: 10, padding: '10px 14px', boxShadow: '0 1px 6px #6B5BFF11' }}>
                <b style={{ color: '#6B5BFF', fontSize: 16 }}>{t.commentsTitle}</b>
                {(msg.comments||[]).length === 0 && <span style={{ color: '#bbb', marginLeft: 8 }}>{t.noComments}</span>}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 6 }}>
                  {(msg.comments||[]).map((c, i) => (
                    <div key={i} style={{ background: '#fff', borderRadius: 8, padding: '6px 12px', color: '#232946', fontSize: 15, border: '1px solid #eee', boxShadow: '0 1px 4px #6B5BFF08' }}><b>{c.nickname}：</b>{c.content}</div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        {showUser && (
          <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.18)', zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ background: '#fff', borderRadius: 28, padding: 36, minWidth: 340, maxWidth: 440, boxShadow: '0 6px 32px #6B5BFF22', textAlign: 'center', position: 'relative', border: '2px solid #6B5BFF22' }}>
              <button onClick={() => setShowUser(null)} style={{ position: 'absolute', top: 12, right: 12, background: 'none', border: 'none', fontSize: 22, color: '#6B4F27', cursor: 'pointer' }}>×</button>
              <img src={showUser.user.avatar} alt="avatar" style={{ width: 90, height: 90, borderRadius: '50%', objectFit: 'cover', marginBottom: 14, border: '2.5px solid #6B5BFF' }} />
              <div style={{ fontWeight: 900, color: '#6B5BFF', fontSize: 22, marginBottom: 8 }}>{showUser.user.name}</div>
              <div style={{ color: '#6B4F27', fontSize: 17, marginBottom: 8 }}>{showUser.user.country}・{showUser.user.region}</div>
              <div style={{ color: '#232946', fontSize: 16, marginBottom: 18 }}>{t.modalTitle}<br />{showUser.text}</div>
              <div style={{ color: '#6B5BFF', fontWeight: 700, marginBottom: 8, fontSize: 16 }}>{t.modalAction}</div>
              <input placeholder={t.nicknamePlaceholder} value={commentNickname} onChange={e => setCommentNickname(e.target.value)} style={{ width: '92%', padding: 10, borderRadius: 8, border: '1px solid #ddd', marginBottom: 10, fontSize: 16 }} />
              <textarea placeholder={t.commentPlaceholder} value={commentInput} onChange={e => setCommentInput(e.target.value)} style={{ width: '92%', padding: 10, borderRadius: 8, border: '1px solid #ddd', minHeight: 54, fontSize: 16 }} />
              <button onClick={() => handleAddComment(showUser)} style={{ marginTop: 12, padding: '10px 22px', background: 'linear-gradient(135deg, #6B5BFF 60%, #23c6e6 100%)', color: '#fff', border: 'none', borderRadius: 10, fontWeight: 900, fontSize: 16, letterSpacing: 1 }}>{t.submitComment}</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
} 