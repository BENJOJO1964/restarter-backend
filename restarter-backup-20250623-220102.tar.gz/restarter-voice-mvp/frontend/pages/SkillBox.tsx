import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAuth, signOut } from 'firebase/auth';
import { useVideoReaction } from '../components/VideoReactionContext';
import { VideoReactionType } from '../components/VideoReactionPlayer';

type LanguageCode = 'zh-TW' | 'zh-CN' | 'en' | 'ja' | 'ko' | 'th' | 'vi' | 'ms' | 'la';

const LANGS: { code: LanguageCode; label: string }[] = [
  { code: 'zh-TW', label: '繁中' },
  { code: 'zh-CN', label: '简中' },
  { code: 'en', label: 'EN' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'th', label: 'ภาษาไทย' },
  { code: 'vi', label: 'Tiếng Việt' },
  { code: 'ms', label: 'Bahasa Melayu' },
  { code: 'la', label: 'Latīna' },
];

const UI_TEXT = {
  backToHome: { 'zh-TW': '← 返回首頁', 'zh-CN': '← 返回首页', 'ja': '← ホームへ戻る', 'en': '← Home', 'ko': '← 홈으로 돌아가기', 'th': '← กลับหน้าหลัก', 'vi': '← Về trang chủ', 'ms': '← Kembali ke Laman Utama', 'la': '← Ad domum redire' },
  logout: { 'zh-TW': '登出', 'zh-CN': '登出', 'ja': 'ログアウト', 'en': 'Logout', 'ko': '로그아웃', 'th': 'ออกจากระบบ', 'vi': 'Đăng xuất', 'ms': 'Log keluar', 'la': 'Exire' },
  pageTitle: { 
    'zh-TW': '情境模擬室 SkillBox', 
    'zh-CN': '情境模拟室 SkillBox', 
    'en': 'SkillBox Scenario Room', 
    'ja': 'シナリオ練習室 SkillBox', 
    'ko': '상황 시뮬레이션실 SkillBox', 
    'th': 'ห้องจำลองสถานการณ์ SkillBox', 
    'vi': 'Phòng mô phỏng tình huống SkillBox', 
    'ms': 'Bilik Senario SkillBox', 
    'la': 'Camera Scaenarii SkillBox' 
  },
  subtitle: { 
    'zh-TW': '在這裡磨練你的對話技巧，應對各種挑戰。', 
    'zh-CN': '在这里磨练你的对话技巧，应对各种挑战。', 
    'en': 'Hone your conversation skills here for any challenge.', 
    'ja': 'ここで会話スキルを磨き、様々な挑戦に備えましょう。', 
    'ko': '여기서 대화 기술을 연마하여 모든 도전에 대비하세요.', 
    'th': 'ฝึกฝนทักษะการสนทนาของคุณที่นี่เพื่อรับมือกับทุกความท้าทาย', 
    'vi': 'Rèn luyện kỹ năng trò chuyện của bạn ở đây cho mọi thử thách.', 
    'ms': 'Asah kemahiran perbualan anda di sini untuk sebarang cabaran.', 
    'la': 'Hic peritiam colloquii tui exacue ad quamvis provocationem.' 
  },
  selectScenario: { 
    'zh-TW': '選擇一個情境開始練習', 
    'zh-CN': '选择一个情境开始练习', 
    'en': 'Select a scenario to start practicing', 
    'ja': '練習を始めるシナリオを選択してください', 
    'ko': '연습을 시작할 시나리오를 선택하세요', 
    'th': 'เลือกสถานการณ์เพื่อเริ่มฝึก', 
    'vi': 'Chọn một kịch bản để bắt đầu luyện tập', 
    'ms': 'Pilih senario untuk mula berlatih', 
    'la': 'Scaenarium elige ut exercere incipias' 
  },
  startPractice: { 
    'zh-TW': '進入模擬', 
    'zh-CN': '进入模拟', 
    'en': 'Enter Simulation', 
    'ja': 'シミュレーションに入る', 
    'ko': '시뮬레이션 시작', 
    'th': 'เข้าสู่การจำลอง', 
    'vi': 'Vào mô phỏng', 
    'ms': 'Masuk Simulasi', 
    'la': 'Intra Simulationem' 
  },
  scenarioTitle: {
    'zh-TW': '情境',
    'zh-CN': '情境',
    'en': 'Scenario',
    'ja': 'シナリオ',
    'ko': '시나리오',
    'th': 'สถานการณ์',
    'vi': 'Kịch bản',
    'ms': 'Senario',
    'la': 'Scaenarium',
  },
  scenarioDesc: {
    'zh-TW': '描述',
    'zh-CN': '描述',
    'en': 'Description',
    'ja': '説明',
    'ko': '설명',
    'th': 'คำอธิบาย',
    'vi': 'Mô tả',
    'ms': 'Penerangan',
    'la': 'Descriptio',
  },
  scenarioDifficulty: {
    'zh-TW': '難度',
    'zh-CN': '难度',
    'en': 'Difficulty',
    'ja': '難易度',
    'ko': '난이도',
    'th': 'ความยาก',
    'vi': 'Độ khó',
    'ms': 'Kesukaran',
    'la': 'Difficultas',
  }
};

export type Scenario = {
    id: number;
    title: string;
    description: string;
    difficulty: string;
    img: string;
    initialPrompt: string;
    videoReaction: VideoReactionType;
};

export default function SkillBox() {
  const navigate = useNavigate();
  const auth = getAuth();
  const lang = (localStorage.getItem('lang') as LanguageCode) || 'zh-TW';
  const { setVideoReaction } = useVideoReaction();
  const [selectedScenarioId, setSelectedScenarioId] = useState<number | null>(null);
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchScenarios = async () => {
      setLoading(true);
      try {
        const response = await fetch(`/api/scenarios?lang=${lang}`);
        if (!response.ok) {
          throw new Error('Failed to fetch scenarios');
        }
        const data = await response.json();
        setScenarios(data);
      } catch (error) {
        console.error("Error fetching scenarios:", error);
        // Optionally set some error state to show in the UI
      } finally {
        setLoading(false);
      }
    };

    fetchScenarios();
  }, [lang]);

  const handleStartPractice = () => {
    if (selectedScenarioId) {
      const scenario = scenarios.find(s => s.id === selectedScenarioId);
      if (scenario?.videoReaction) {
        setVideoReaction(scenario.videoReaction);
      }
      navigate(`/skillbox/${selectedScenarioId}`);
    } else {
      alert(UI_TEXT.selectScenario[lang]);
    }
  };

  if (loading) {
      return <div>Loading scenarios...</div>;
  }

  return (
    <div className="modern-bg" style={{ background: `url('/plains.png') center center / cover no-repeat`, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{position:'absolute',top:0,left:0,zIndex:100,display:'flex',alignItems:'center',padding:'18px 32px 0 32px',background:'transparent'}}>
        <button className="topbar-btn" onClick={()=>navigate('/')} style={{fontWeight:700,fontSize:18,padding:'6px 16px',borderRadius:8,border:'1.5px solid #6B5BFF',background:'#fff',color:'#6B5BFF',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s', marginRight:8}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>{UI_TEXT.backToHome[lang]}</button>
      </div>
      <div style={{position:'absolute',top:0,right:0,zIndex:100,display:'flex',alignItems:'center',padding:'18px 32px 0 32px',background:'transparent',gap:12}}>
        <button className="topbar-btn" onClick={async()=>{await signOut(auth);localStorage.clear();window.location.href='/'}} style={{fontWeight:700,fontSize:18,padding:'6px 16px',borderRadius:8,border:'1.5px solid #6B5BFF',background:'#fff',color:'#6B5BFF',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s'}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>{UI_TEXT.logout[lang]}</button>
        <select className="topbar-select" value={lang} onChange={e=>{localStorage.setItem('lang',e.target.value as LanguageCode);window.location.reload();}} style={{padding:'6px 14px',borderRadius:8,fontWeight:600,border:'1.5px solid #6B5BFF',color:'#6B5BFF',background:'#fff',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s'}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>
          {LANGS.map(l => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', width: '100%', padding: '24px' }}>
        <h2 style={{ fontSize: '2.2rem', fontWeight: 900, color: '#6B5BFF', textShadow: '0 2px 12px #6B5BFF88, 0 4px 24px #0008', letterSpacing:1, background:'#fff', borderRadius:12, boxShadow:'0 2px 12px #6B5BFF22', padding:'12px 32px', margin:0, marginBottom: 12, display:'flex',alignItems:'center',gap:12 }}>💡 {UI_TEXT.pageTitle[lang]}</h2>
        <div style={{ fontSize: 18, color: '#4A4A4A', fontWeight: 500, marginBottom: 24, textAlign:'center', background:'rgba(255,255,255,0.7)', padding:'8px 16px', borderRadius:8 }}>{UI_TEXT.subtitle[lang]}</div>
        
        <div style={{ maxWidth: 800, width: '100%', background: '#fff', borderRadius: 16, padding: '24px 32px', boxShadow: '0 4px 24px #0002', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <h3 style={{ fontSize: 24, fontWeight: 700, color: '#6B5BFF', marginBottom: 24 }}>{UI_TEXT.selectScenario[lang]}</h3>
          
          <div style={{ width: '100%', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '24px' }}>
            {scenarios.map(scenario => (
              <div 
                key={scenario.id}
                onClick={() => setSelectedScenarioId(scenario.id)}
                style={{ 
                  background: selectedScenarioId === scenario.id ? 'linear-gradient(135deg, #6B5BFF 0%, #4D8FFF 100%)' : '#f7f7ff', 
                  color: selectedScenarioId === scenario.id ? '#fff' : '#4A4A4A',
                  borderRadius: 12, 
                  padding: 20, 
                  boxShadow: selectedScenarioId === scenario.id ? '0 8px 24px #6B5BFF66' : '0 4px 12px #0000001a', 
                  cursor: 'pointer', 
                  transition: 'all 0.3s ease',
                  border: selectedScenarioId === scenario.id ? '2px solid #fff' : '2px solid transparent',
                  transform: selectedScenarioId === scenario.id ? 'translateY(-5px)' : 'none',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center'
                }}
              >
                <div style={{ fontSize: 48, marginBottom: 12 }}>{scenario.img}</div>
                <h4 style={{ fontSize: 18, fontWeight: 700, margin: '0 0 8px 0' }}>{scenario.title}</h4>
                <p style={{ fontSize: 14, margin: '0 0 12px 0', opacity: 0.8, minHeight: '40px' }}>{scenario.description}</p>
                <div style={{ fontWeight: 600, fontSize: 14, padding: '4px 12px', borderRadius: 16, background: selectedScenarioId === scenario.id ? 'rgba(255,255,255,0.2)' : 'rgba(107, 91, 255, 0.1)', color: selectedScenarioId === scenario.id ? '#fff' : '#6B5BFF' }}>
                    {UI_TEXT.scenarioDifficulty[lang]}: {scenario.difficulty}
                </div>
              </div>
            ))}
          </div>

          <button 
            onClick={handleStartPractice}
            disabled={!selectedScenarioId}
            style={{ 
              marginTop: 32, 
              padding: '12px 48px', 
              borderRadius: 12, 
              fontWeight: 700, 
              background: !selectedScenarioId ? '#ccc' : 'linear-gradient(135deg, #6B5BFF 60%, #23c6e6 100%)', 
              color: '#fff', 
              border: 'none', 
              fontSize: 18, 
              cursor: !selectedScenarioId ? 'not-allowed' : 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: !selectedScenarioId ? 'none' : '0 6px 32px #6B5BFF99',
              transform: 'scale(1)',
            }}
            onMouseOver={e => { if (selectedScenarioId) { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.background = 'linear-gradient(135deg, #3a2fff 60%, #0e7fd6 100%)'; } }}
            onMouseOut={e => { if (selectedScenarioId) { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.background = 'linear-gradient(135deg, #6B5BFF 60%, #23c6e6 100%)';} }}
          >
            {UI_TEXT.startPractice[lang]}
          </button>
        </div>
      </div>
    </div>
  );
} 