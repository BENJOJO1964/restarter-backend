import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAuth, signOut } from 'firebase/auth';

type LanguageCode = 'zh-TW' | 'zh-CN' | 'en' | 'ja' | 'ko' | 'th' | 'vi' | 'ms' | 'la';

const LANGS: { code: LanguageCode; label: string }[] = [
  { code: 'zh-TW', label: '繁中' },
  { code: 'zh-CN', label: '简中' },
  { code: 'en', label: 'EN' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'th', label: 'ภาษาไทย' },
  { code: 'vi', label: 'Tiếng Việt' },
  { code: 'ms', label: 'Bahasa Melayu' },
  { code: 'la', label: 'Latīna' },
];

const UI_TEXT = {
  backToHome: { 'zh-TW': '← 返回首頁', 'zh-CN': '← 返回首页', 'ja': '← ホームへ戻る', 'en': '← Home', 'ko': '← 홈으로 돌아가기', 'th': '← กลับหน้าหลัก', 'vi': '← Về trang chủ', 'ms': '← Kembali ke Laman Utama', 'la': '← Ad domum redire' },
  back: { 'zh-TW': '↩ 返回上一頁', 'zh-CN': '↩ 返回上一页', 'ja': '↩ 前のページへ', 'en': '↩ Back', 'ko': '↩ 이전 페이지로', 'th': '↩ กลับไป', 'vi': '↩ Quay lại', 'ms': '↩ Kembali', 'la': '↩ Redire' },
  logout: { 'zh-TW': '登出', 'zh-CN': '登出', 'ja': 'ログアウト', 'en': 'Logout', 'ko': '로그아웃', 'th': 'ออกจากระบบ', 'vi': 'Đăng xuất', 'ms': 'Log keluar', 'la': 'Exire' },
  pageTitle: { 'zh-TW': '交友區 Friend Match', 'zh-CN': '交友区 Friend Match', 'ja': '友達マッチ Friend Match', 'en': 'Friend Match', 'ko': '친구 매칭', 'th': 'จับคู่เพื่อน', 'vi': 'Ghép bạn', 'ms': 'Padanan Rakan', 'la': 'Par Amicus' },
  formTitle: { 'zh-TW': '理想朋友條件', 'zh-CN': '理想朋友条件', 'ja': '理想の友達条件', 'en': 'Ideal Friend Conditions', 'ko': '이상적인 친구 조건', 'th': 'เงื่อนไขเพื่อนในอุดมคติ', 'vi': 'Điều kiện bạn bè lý tưởng', 'ms': 'Syarat Rakan Ideal', 'la': 'Condiciones Amici Idealis' },
  gender: { 'zh-TW': '性別', 'zh-CN': '性别', 'ja': '性別', 'en': 'Gender', 'ko': '성별', 'th': 'เพศ', 'vi': 'Giới tính', 'ms': 'Jantina', 'la': 'Genus' },
  male: { 'zh-TW': '男', 'zh-CN': '男', 'ja': '男性', 'en': 'Male', 'ko': '남성', 'th': 'ชาย', 'vi': 'Nam', 'ms': 'Lelaki', 'la': 'Mas' },
  female: { 'zh-TW': '女', 'zh-CN': '女', 'ja': '女性', 'en': 'Female', 'ko': '여성', 'th': 'หญิง', 'vi': 'Nữ', 'ms': 'Perempuan', 'la': 'Femina' },
  age: { 'zh-TW': '年齡', 'zh-CN': '年龄', 'ja': '年齢', 'en': 'Age', 'ko': '나이', 'th': 'อายุ', 'vi': 'Tuổi', 'ms': 'Umur', 'la': 'Aetas' },
  eventType: { 'zh-TW': '事件類型', 'zh-CN': '事件类型', 'ja': 'イベントタイプ', 'en': 'Event Type', 'ko': '이벤트 유형', 'th': 'ประเภทเหตุการณ์', 'vi': 'Loại sự kiện', 'ms': 'Jenis Acara', 'la': 'Genus Eventus' },
  country: { 'zh-TW': '國家(地區)', 'zh-CN': '国家(地区)', 'ja': '国(地域)', 'en': 'Country(Region)', 'ko': '국가(지역)', 'th': 'ประเทศ(ภูมิภาค)', 'vi': 'Quốc gia(Khu vực)', 'ms': 'Negara(Wilayah)', 'la': 'Natio(Regio)' },
  city: { 'zh-TW': '城市', 'zh-CN': '城市', 'ja': '都市', 'en': 'City', 'ko': '도시', 'th': 'เมือง', 'vi': 'Thành phố', 'ms': 'Bandar', 'la': 'Urbs' },
  interest: { 'zh-TW': '興趣', 'zh-CN': '兴趣', 'ja': '趣味', 'en': 'Interest', 'ko': '관심사', 'th': 'ความสนใจ', 'vi': 'Sở thích', 'ms': 'Minat', 'la': 'Studium' },
  save: { 'zh-TW': '儲存資料', 'zh-CN': '保存资料', 'ja': 'データ保存', 'en': 'Save', 'ko': '저장', 'th': 'บันทึก', 'vi': 'Lưu', 'ms': 'Simpan', 'la': 'Servare' },
  saved: { 'zh-TW': '已儲存！', 'zh-CN': '已保存！', 'ja': '保存しました！', 'en': 'Saved!', 'ko': '저장됨!', 'th': 'บันทึกแล้ว!', 'vi': 'Đã lưu!', 'ms': 'Disimpan!', 'la': 'Servatum!' },
  invite: { 'zh-TW': '邀請交友', 'zh-CN': '邀请交友', 'ja': '友達招待', 'en': 'Invite Friend', 'ko': '친구 초대', 'th': 'เชิญเพื่อน', 'vi': 'Mời bạn', 'ms': 'Jemput Rakan', 'la': 'Amicum Invitare' },
  invited: { 'zh-TW': '已邀請', 'zh-CN': '已邀请', 'ja': '招待済み', 'en': 'Invited', 'ko': '초대됨', 'th': 'เชิญแล้ว', 'vi': 'Đã mời', 'ms': 'Telah dijemput', 'la': 'Invitatus' },
  prevPage: { 'zh-TW': '上一頁', 'zh-CN': '上一页', 'ja': '前へ', 'en': 'Previous Page', 'ko': '이전 페이지', 'th': 'หน้าก่อนหน้า', 'vi': 'Trang trước', 'ms': 'Halaman Sebelumnya', 'la': 'Pagina Prior' },
  nextPage: { 'zh-TW': '下一頁', 'zh-CN': '下一页', 'ja': '次へ', 'en': 'Next Page', 'ko': '다음 페이지', 'th': 'หน้าถัดไป', 'vi': 'Trang tiếp theo', 'ms': 'Halaman Seterusnya', 'la': 'Pagina Proxima' },
};

const mockUsers = [
    { id: 1, name: 'Alice', country: '台灣', region: '台北', interest: '閱讀', email: 'alice@example.com', gender: '女' },
    { id: 2, name: 'Bob', country: '日本', region: '東京', interest: '音樂', email: 'bob@example.com', gender: '男' },
    { id: 3, name: 'Carol', country: '美國', region: '舊金山', interest: '運動', email: 'carol@example.com', gender: '女' },
    { id: 4, name: 'Alice', country: '台灣', region: '台北', interest: '運動', email: 'alice@example.com', gender: '女' },
    { id: 5, name: 'David', country: '英國', region: '倫敦', interest: '電影', email: 'david@example.com', gender: '男' },
    { id: 6, name: 'Eve', country: '法國', region: '巴黎', interest: '旅行', email: 'eve@example.com', gender: '女' },
    { id: 7, name: 'Frank', country: '德國', region: '柏林', interest: '烹飪', email: 'frank@example.com', gender: '男' },
    { id: 8, name: 'Grace', country: '加拿大', region: '多倫多', interest: '遊戲', email: 'grace@example.com', gender: '女' },
    { id: 9, name: 'Henry', country: '澳洲', region: '雪梨', interest: '攝影', email: 'henry@example.com', gender: '男' },
    { id: 10, name: 'Ivy', country: '紐西蘭', region: '奧克蘭', interest: '藝術', email: 'ivy@example.com', gender: '女' },
    { id: 11, name: 'Jack', country: '新加坡', region: '新加坡', interest: '科技', email: 'jack@example.com', gender: '男' },
    { id: 12, name: 'Kate', country: '馬來西亞', region: '吉隆坡', interest: '時尚', email: 'kate@example.com', gender: '女' },
    { id: 13, name: 'Leo', country: '台灣', region: '高雄', interest: '閱讀', email: 'leo@example.com', gender: '男' },
    { id: 14, name: 'Mia', country: '日本', region: '大阪', interest: '音樂', email: 'mia@example.com', gender: '女' },
    { id: 15, name: 'Noah', country: '美國', region: '紐約', interest: '運動', email: 'noah@example.com', gender: '男' }
  ];
  
  const COUNTRY_OPTIONS = {
    'zh-TW': ['台灣','中國大陸','日本','韓國','馬來西亞','新加坡','印尼','越南','菲律賓','英國','法國','德國','美國','加拿大','非洲','歐洲','南美洲','中東','其他'],
    'zh-CN': ['台湾','中国大陆','日本','韩国','马来西亚','新加坡','印尼','越南','菲律宾','英国','法国','德国','美国','加拿大','非洲','欧洲','南美洲','中东','其他'],
    'en': ['Taiwan','China','Japan','Korea','Malaysia','Singapore','Indonesia','Vietnam','Philippines','UK','France','Germany','USA','Canada','Africa','Europe','South America','Middle East','Other'],
    'ja': ['台湾','中国','日本','韓国','マレーシア','シンガポール','インドネシア','ベトナム','フィリピン','イギリス','フランス','ドイツ','アメリカ','カナダ','アフリカ','ヨーロッパ','南アメリカ','中東','その他'],
    'ko': ['대만','중국','일본','한국','말레이시아','싱가포르','인도네시아','베트남','필리핀','영국','프랑스','독일','미국','캐나다','아프리카','유럽','남아메리카','중동','기타'],
    'th': ['ไต้หวัน','จีน','ญี่ปุ่น','เกาหลี','มาเลเซีย','สิงคโปร์','อินโดนีเซีย','เวียดนาม','ฟิลิปปินส์','สหราชอาณาจักร','ฝรั่งเศส','เยอรมนี','สหรัฐอเมริกา','แคนาดา','แอฟริกา','ยุโรป','อเมริกาใต้','ตะวันออกกลาง','อื่นๆ'],
    'vi': ['Đài Loan','Trung Quốc','Nhật Bản','Hàn Quốc','Malaysia','Singapore','Indonesia','Việt Nam','Philippines','Vương quốc Anh','Pháp','Đức','Hoa Kỳ','Canada','Châu Phi','Châu Âu','Nam Mỹ','Trung Đông','Khác'],
    'ms': ['Taiwan','China','Jepun','Korea','Malaysia','Singapura','Indonesia','Vietnam','Filipina','UK','Perancis','Jerman','AS','Kanada','Afrika','Eropah','Amerika Selatan','Timur Tengah','Lain-lain'],
    'la': ['Taivania','Sina','Iaponia','Corea','Malaisia','Singapura','Indonesia','Vietnamia','Philippinae','Britanniarum Regnum','Gallia','Germania','USA','Canada','Africa','Europa','America Meridionalis','Oriens Medius','Aliud'],
  };
  const AGE_RANGE_OPTIONS = {
    'zh-TW': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
    'zh-CN': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
    'en': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
    'ja': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
    'ko': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
    'th': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
    'vi': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
    'ms': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
    'la': ['18-23','24-28','29-33','34-39','40-46','47-51','52-58','59-64','65-72','73-80'],
  };
  const INTEREST_OPTIONS = {
    'zh-TW': ['經濟','運動','閱讀','電影','旅遊','交友','唱歌','電商','做生意','電腦','AI','其他'],
    'zh-CN': ['经济','运动','阅读','电影','旅游','交友','唱歌','电商','做生意','电脑','AI','其他'],
    'en': ['Economy','Sports','Reading','Movie','Travel','Friendship','Singing','E-commerce','Business','Computer','AI','Other'],
    'ja': ['経済','スポーツ','読書','映画','旅行','友達','カラオケ','EC','ビジネス','パソコン','AI','その他'],
    'ko': ['경제','스포츠','독서','영화','여행','친구 사귀기','노래','전자상거래','사업','컴퓨터','AI','기타'],
    'th': ['เศรษฐกิจ','กีฬา','การอ่าน','ภาพยนตร์','การเดินทาง','มิตรภาพ','การร้องเพลง','อีคอมเมิร์ซ','ธุรกิจ','คอมพิวเตอร์','AI','อื่นๆ'],
    'vi': ['Kinh tế','Thể thao','Đọc sách','Phim ảnh','Du lịch','Tình bạn','Ca hát','Thương mại điện tử','Kinh doanh','Máy tính','AI','Khác'],
    'ms': ['Ekonomi','Sukan','Membaca','Filem','Melancong','Persahabatan','Menyanyi','E-dagang','Perniagaan','Komputer','AI','Lain-lain'],
    'la': ['Oeconomia','Ludi','Lectio','Pellicula','Iter','Amicitia','Cantus','E-commercium','Negotium','Computatrum','AI','Aliud'],
  };
  const EVENT_TYPE_OPTIONS = {
    'zh-TW': ['經濟','政治','科技','法律','毒品','民事','傷害'],
    'zh-CN': ['经济','政治','科技','法律','毒品','民事','伤害'],
    'en': ['Economy','Politics','Technology','Law','Drugs','Civil','Injury'],
    'ja': ['経済','政治','テクノロジー','法律','薬物','民事','傷害'],
    'ko': ['경제','정치','기술','법률','마약','민사','상해'],
    'th': ['เศรษฐกิจ','การเมือง','เทคโนโลยี','กฎหมาย','ยาเสพติด','ทางแพ่ง','การบาดเจ็บ'],
    'vi': ['Kinh tế','Chính trị','Công nghệ','Luật pháp','Ma túy','Dân sự','Thương tích'],
    'ms': ['Ekonomi','Politik','Teknologi','Undang-undang','Dadah','Sivil','Kecederaan'],
    'la': ['Oeconomia','Politica','Technologia','Lex','Medicamenta','Civilis','Iniuria'],
  };
  
  export default function FriendMatch() {
    const navigate = useNavigate();
    const auth = getAuth();
    const lang = (localStorage.getItem('lang') as LanguageCode) || 'zh-TW';
    const [form, setForm] = useState({ gender: '', age: '', eventType: '', country: '', region: '', interest: '' });
    const [filteredUsers, setFilteredUsers] = useState(mockUsers);
    const [sent, setSent] = useState(false);
    const [inviteTo, setInviteTo] = useState<number | null>(null);
    const [page, setPage] = useState(0);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      setPage(0); // Reset to first page on new search
      const filtered = mockUsers.filter(user => {
        return (form.gender ? user.gender === form.gender : true) &&
               (form.country ? user.country === form.country : true) &&
               (form.interest ? user.interest === form.interest : true);
      });
      setFilteredUsers(filtered);
      setSent(true);
      setTimeout(() => setSent(false), 2000);
      console.log('Form submitted, filters applied:', form);
    };
    
    const handleInvite = (userId: number) => {
      setInviteTo(userId);
      setTimeout(() => setInviteTo(null), 2000);
    };

    const usersPerPage = 12;
    const paginatedUsers = filteredUsers.slice(page * usersPerPage, (page + 1) * usersPerPage);
    const hasMorePages = (page + 1) * usersPerPage < filteredUsers.length;

    return (
      <div className="modern-bg" style={{ background: `url('/green_hut.png') center center / cover no-repeat`, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{position:'absolute',top:0,left:0,zIndex:100,display:'flex',alignItems:'center',padding:'18px 32px 0 32px',background:'transparent'}}>
          <button className="topbar-btn" onClick={()=>navigate('/')} style={{fontWeight:700,fontSize:18,padding:'6px 16px',borderRadius:8,border:'1.5px solid #6B5BFF',background:'#fff',color:'#6B5BFF',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s', marginRight:8}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>{UI_TEXT.backToHome[lang]}</button>
          {window.location.pathname!=='/friend' && <button className="topbar-btn" onClick={()=>navigate(-1)} style={{fontWeight:700,fontSize:18,padding:'6px 16px',borderRadius:8,border:'1.5px solid #6B5BFF',background:'#fff',color:'#6B5BFF',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s', marginLeft:8}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>{UI_TEXT.back[lang]}</button>}
        </div>
        <div style={{position:'absolute',top:0,right:0,zIndex:100,display:'flex',alignItems:'center',padding:'18px 32px 0 32px',background:'transparent',gap:12}}>
          <button className="topbar-btn" onClick={async()=>{await signOut(auth);localStorage.clear();window.location.href='/'}} style={{fontWeight:700,fontSize:18,padding:'6px 16px',borderRadius:8,border:'1.5px solid #6B5BFF',background:'#fff',color:'#6B5BFF',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s'}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>{UI_TEXT.logout[lang]}</button>
          <select className="topbar-select" value={lang} onChange={e=>{localStorage.setItem('lang',e.target.value);window.location.reload();}} style={{padding:'6px 14px',borderRadius:8,fontWeight:600,border:'1.5px solid #6B5BFF',color:'#6B5BFF',background:'#fff',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s'}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>
            {LANGS.map(l => (
              <option key={l.code} value={l.code}>{l.label}</option>
            ))}
          </select>
        </div>
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 100 }}>
          <h2 style={{ fontSize: '2.2rem', fontWeight: 900, color: '#6B5BFF', textShadow: '0 2px 12px #6B5BFF88, 0 4px 24px #0008', letterSpacing:1, background:'#fff', borderRadius:12, boxShadow:'0 2px 12px #6B5BFF22', padding:'12px 32px', margin:0, display:'flex',alignItems:'center',gap:12, marginBottom: 24 }}>🧑‍🤝‍🧑 {UI_TEXT.pageTitle[lang]}</h2>
          <div className="modern-container" style={{ maxWidth: 700, width: '100%', margin: '0 auto', padding: 32, display: 'flex', flexDirection: 'column', gap: 24, alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', flexDirection: 'row', gap: 32, alignItems: 'flex-start' }}>
              <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16, flex: 1, paddingRight: 32, borderRight: '1.5px solid #6B5BFF33' }}>
                <h3 style={{ fontSize: 22, fontWeight: 700, color: '#FFFFFF', margin: 0 }}>{UI_TEXT.formTitle[lang]}</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                  <select name="gender" value={form.gender} onChange={handleChange} style={{ padding: 10, borderRadius: 8, border: '1px solid #ddd' }}>
                    <option value="">{UI_TEXT.gender[lang]}</option>
                    <option value="男">{UI_TEXT.male[lang]}</option>
                    <option value="女">{UI_TEXT.female[lang]}</option>
                  </select>
                  <select name="age" value={form.age} onChange={handleChange} style={{ padding: 10, borderRadius: 8, border: '1px solid #ddd' }}>
                    <option value="">{UI_TEXT.age[lang]}</option>
                    {AGE_RANGE_OPTIONS[lang].map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                  <select name="eventType" value={form.eventType} onChange={handleChange} style={{ padding: 10, borderRadius: 8, border: '1px solid #ddd' }}>
                    <option value="">{UI_TEXT.eventType[lang]}</option>
                    {EVENT_TYPE_OPTIONS[lang].map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                  <select name="country" value={form.country} onChange={handleChange} style={{ padding: 10, borderRadius: 8, border: '1px solid #ddd' }}>
                    <option value="">{UI_TEXT.country[lang]}</option>
                    {COUNTRY_OPTIONS[lang].map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                  <input name="region" placeholder={UI_TEXT.city[lang]} value={form.region} onChange={handleChange} style={{ padding: 10, borderRadius: 8, border: '1px solid #ddd' }} />
                  <select name="interest" value={form.interest} onChange={handleChange} style={{ padding: 10, borderRadius: 8, border: '1px solid #ddd' }}>
                    <option value="">{UI_TEXT.interest[lang]}</option>
                    {INTEREST_OPTIONS[lang].map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                  <button type="submit" style={{ gridColumn: 'span 2', padding: 12, background: 'linear-gradient(135deg, #6B5BFF 60%, #23c6e6 100%)', color: '#fff', border: 'none', borderRadius: 10, fontWeight: 900, fontSize: 17, marginTop: 8, letterSpacing: 1, boxShadow: '0 2px 12px #6B5BFF33', cursor: 'pointer' }}>{UI_TEXT.save[lang]}</button>
                  {sent && <div style={{ color: '#6B5BFF', fontWeight: 700, gridColumn: 'span 2', textAlign: 'center' }}>{UI_TEXT.saved[lang]}</div>}
                </div>
              </form>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 16, maxHeight: 400, overflowY: 'auto', paddingRight: '10px' }}>
                {paginatedUsers.map((user, index) => (
                  <div key={user.id} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 16, background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #6B5BFF22' }}>
                    <img src={`/avatars/avatar.png`} alt={user.name} style={{ width: 64, height: 64, borderRadius: '50%' }} />
                    <div style={{ flex: 1 }}>
                      <h4 style={{ margin: 0, fontSize: 18, fontWeight: 700 }}>{user.name}</h4>
                      <p style={{ margin: '4px 0', fontSize: 14 }}>{UI_TEXT.country[lang]}: {user.country}</p>
                      <p style={{ margin: '4px 0', fontSize: 14 }}>{UI_TEXT.city[lang]}: {user.region}</p>
                      <p style={{ margin: '4px 0', fontSize: 14 }}>{UI_TEXT.interest[lang]}: {user.interest}</p>
                      <p style={{ margin: '4px 0', fontSize: 14 }}>Email: {user.email}</p>
                    </div>
                    <button onClick={() => handleInvite(user.id)} className="modern-button-purple" style={{ padding: '8px 16px', fontSize: 14 }}>
                      {inviteTo === user.id ? UI_TEXT.invited[lang] : UI_TEXT.invite[lang]}
                    </button>
                  </div>
                ))}
                {(hasMorePages || page > 0) && (
                  <div style={{ display: 'flex', justifyContent: 'center', gap: '16px', marginTop: 16 }}>
                    {page > 0 && (
                        <button 
                          onClick={() => setPage(p => p - 1)} 
                          className="prev-page-btn"
                          style={{ 
                            padding: '8px 24px', 
                            fontSize: 16, 
                            fontWeight: 700,
                            background: '#6B5BFF',
                            color: 'white',
                            border: 'none',
                            borderRadius: '8px',
                            cursor: 'pointer',
                            transition: 'background-color 0.3s'
                          }}
                          onMouseOver={e => e.currentTarget.style.backgroundColor = '#5548CC'}
                          onMouseOut={e => e.currentTarget.style.backgroundColor = '#6B5BFF'}
                        >
                          {UI_TEXT.prevPage[lang]}
                        </button>
                    )}
                    {hasMorePages && (
                      <button 
                        onClick={() => setPage(p => p + 1)} 
                        className="next-page-btn"
                        style={{ 
                          padding: '8px 24px', 
                          fontSize: 16, 
                          fontWeight: 700,
                          background: '#6B5BFF',
                          color: 'white',
                          border: 'none',
                          borderRadius: '8px',
                          cursor: 'pointer',
                          transition: 'background-color 0.3s'
                        }}
                        onMouseOver={e => e.currentTarget.style.backgroundColor = '#5548CC'}
                        onMouseOut={e => e.currentTarget.style.backgroundColor = '#6B5BFF'}
                      >
                        {UI_TEXT.nextPage[lang]}
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } 