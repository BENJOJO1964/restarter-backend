import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAuth, signOut } from 'firebase/auth';

type LanguageCode = 'zh-TW' | 'zh-CN' | 'en' | 'ja' | 'ko' | 'th' | 'vi' | 'ms' | 'la';

const LANGS: { code: LanguageCode; label: string }[] = [
  { code: 'zh-TW', label: '繁中' },
  { code: 'zh-CN', label: '简中' },
  { code: 'en', label: 'EN' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'th', label: 'ภาษาไทย' },
  { code: 'vi', label: 'Tiếng Việt' },
  { code: 'la', label: 'Latīna' },
  { code: 'ms', label: 'Bahasa Melayu' },
];

const TEXT = {
  'zh-TW': {
    pathTitle: "重啟之路",
    pathSubtitle: "一步步走出迷霧，看見全新的自己",
    stage1Title: "第一站：迷霧山谷",
    stage1Mission: "寫下最近一件讓你感到強烈情緒的事。不必評判自己，單純描述事情的經過、你的感受，以及這個感受帶來的影響。",
    submitButton: "提交，尋求指引",
    aiCoach: "AI 教練",
    aiLoading: "正在深度傾聽您的故事，並從中尋找力量與智慧...",
    badgeWall: "成就勳章牆",
    backToHome: "← 返回首頁",
    logout: "登出",
  },
  'zh-CN': {
    pathTitle: "重启之路",
    pathSubtitle: "一步步走出迷雾，看见全新的自己",
    stage1Title: "第一站：迷雾山谷",
    stage1Mission: "写下最近一件让你感到强烈情绪的事。不必评判自己，单纯描述事情的经过、你的感受，以及这个感受带来的影响。",
    submitButton: "提交，寻求指引",
    aiCoach: "AI 教练",
    aiLoading: "正在深度倾听您的故事，并从中寻找力量与智慧...",
    badgeWall: "成就勋章墙",
    backToHome: "← 返回首页",
    logout: "登出",
  },
  'en': {
    pathTitle: "The Path to Restart",
    pathSubtitle: "Step by step, walk out of the mist and see a new you.",
    stage1Title: "Stage 1: The Valley of Mist",
    stage1Mission: "Write about a recent event that evoked a strong emotion in you. Don't judge yourself; simply describe what happened, how you felt, and the impact of that feeling.",
    submitButton: "Submit for Guidance",
    aiCoach: "AI Coach",
    aiLoading: "Deeply listening to your story, seeking strength and wisdom within...",
    badgeWall: "Achievement Badge Wall",
    backToHome: "← Back to Home",
    logout: "Logout",
  },
  'ja': {
    pathTitle: "再起の道",
    pathSubtitle: "一歩ずつ霧を抜け、新しい自分を見つけよう",
    stage1Title: "ステージ1：霧の谷",
    stage1Mission: "最近、強い感情を抱いた出来事を書き出してください。自分を責めず、ただ何が起こったか、どう感じたか、その感情がもたらした影響を記述してください。",
    submitButton: "導きを求めて提出",
    aiCoach: "AIコーチ",
    aiLoading: "あなたの物語に深く耳を傾け、その中から力と知恵を探しています...",
    badgeWall: "実績バッジウォール",
    backToHome: "← ホームへ戻る",
    logout: "ログアウト",
  },
  'ko': {
    pathTitle: "재시작의 길",
    pathSubtitle: "한 걸음씩 안개를 벗어나 새로운 당신을 만나보세요.",
    stage1Title: "1단계: 안개의 계곡",
    stage1Mission: "최근 강한 감정을 불러일으킨 사건에 대해 적어보세요. 자신을 판단하지 말고, 무슨 일이 있었는지, 어떻게 느꼈는지, 그 감정이 미친 영향을 단순히 설명하세요.",
    submitButton: "지침을 위해 제출",
    aiCoach: "AI 코치",
    aiLoading: "당신의 이야기를 깊이 듣고, 그 안에서 힘과 지혜를 찾고 있습니다...",
    badgeWall: "업적 배지 벽",
    backToHome: "← 홈으로 돌아가기",
    logout: "로그아웃",
  },
  'vi': {
    pathTitle: "Con Đường Khởi Đầu Lại",
    pathSubtitle: "Từng bước, bước ra khỏi sương mù và nhìn thấy một con người mới của bạn.",
    stage1Title: "Giai đoạn 1: Thung lũng sương mù",
    stage1Mission: "Viết về một sự kiện gần đây đã gợi lên một cảm xúc mạnh mẽ trong bạn. Đừng phán xét bản thân; chỉ cần mô tả những gì đã xảy ra, bạn cảm thấy thế nào và tác động của cảm giác đó.",
    submitButton: "Gửi để được hướng dẫn",
    aiCoach: "Huấn luyện viên AI",
    aiLoading: "Lắng nghe sâu sắc câu chuyện của bạn, tìm kiếm sức mạnh và trí tuệ bên trong...",
    badgeWall: "Bức tường huy hiệu thành tích",
    backToHome: "← Trở về trang chủ",
    logout: "Đăng xuất",
  },
  'th': {
    pathTitle: "เส้นทางสู่การเริ่มต้นใหม่",
    pathSubtitle: "ก้าวทีละก้าว, เดินออกจากหมอกและพบกับตัวตนใหม่ของคุณ",
    stage1Title: "ด่านที่ 1: หุบเขาแห่งหมอก",
    stage1Mission: "เขียนเกี่ยวกับเหตุการณ์ล่าสุดที่กระตุ้นอารมณ์รุนแรงในตัวคุณ อย่าตัดสินตัวเอง; เพียงแค่อธิบายสิ่งที่เกิดขึ้น, คุณรู้สึกอย่างไร, และผลกระทบของความรู้สึกนั้น.",
    submitButton: "ส่งเพื่อขอคำแนะนำ",
    aiCoach: "โค้ช AI",
    aiLoading: "รับฟังเรื่องราวของคุณอย่างลึกซึ้ง, ค้นหาความแข็งแกร่งและสติปัญญาภายใน...",
    badgeWall: "กำแพงเหรียญตราแห่งความสำเร็จ",
    backToHome: "← กลับสู่หน้าหลัก",
    logout: "ออกจากระบบ",
  },
  'la': {
    pathTitle: "Via ad Novum Initium",
    pathSubtitle: "Gradatim, ex nebula exi et novum te vide.",
    stage1Title: "Gradus I: Vallis Nebulae",
    stage1Mission: "Scribe de recenti eventu qui fortem in te affectum evocavit. Noli te iudicare; simpliciter narra quid acciderit, quomodo senseris, et impulsum illius sensus.",
    submitButton: "Submitte ad Directionem",
    aiCoach: "AI Instructor",
    aiLoading: "Profunde auscultans fabulam tuam, vires et sapientiam intus quaerens...",
    badgeWall: "Murus Insignium rerum gestarum",
    backToHome: "← Ad Domum Redire",
    logout: "Exire",
  },
  'ms': {
    pathTitle: "Laluan untuk Memulakan Semula",
    pathSubtitle: "Langkah demi langkah, keluar dari kabus dan lihat diri anda yang baharu.",
    stage1Title: "Peringkat 1: Lembah Kabus",
    stage1Mission: "Tulis tentang peristiwa baru-baru ini yang menimbulkan emosi yang kuat dalam diri anda. Jangan menghakimi diri sendiri; hanya terangkan apa yang berlaku, bagaimana perasaan anda, dan kesan perasaan itu.",
    submitButton: "Hantar untuk Bimbingan",
    aiCoach: "Jurulatih AI",
    aiLoading: "Mendengar secara mendalam cerita anda, mencari kekuatan dan kebijaksanaan di dalamnya...",
    badgeWall: "Dinding Lencana Pencapaian",
    backToHome: "← Kembali ke Laman Utama",
    logout: "Log keluar",
  },
};

const BADGES = {
  'MIST_VALLEY_COMPLETED': {
    icon: '🌫️',
    'zh-TW': '走出迷霧的第一步',
    'zh-CN': '走出迷雾的第一步',
    'en': 'First Step Out of the Mist',
    'ja': '霧を抜ける第一歩',
    'ko': '안개를 벗어나는 첫 걸음',
    'vi': 'Bước Đầu Tiên Ra Khỏi Màn Sương',
    'th': 'ก้าวแรกที่ออกจากหมอก',
    'la': 'Primus Gradus Ex Nebula',
    'ms': 'Langkah Pertama Keluar dari Kabus',
  }
};

export default function Missions() {
  const navigate = useNavigate();
  const auth = getAuth();
  const [lang, setLang] = useState<LanguageCode>('zh-TW');

  // 使用者旅程狀態
  const [userInput, setUserInput] = useState('');
  const [aiFeedback, setAiFeedback] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>([]);

  const t = TEXT[lang];

  useEffect(() => {
    // Load language from local storage
    const savedLang = localStorage.getItem('lang') as LanguageCode;
    if (savedLang && TEXT[savedLang]) {
      setLang(savedLang);
    }

    const savedJourney = JSON.parse(localStorage.getItem('userJourney') || '{}');
    if (savedJourney.mistValley?.completed) {
      setUnlockedBadges(prev => [...new Set([...prev, 'MIST_VALLEY_COMPLETED'])]);
      setUserInput(savedJourney.mistValley.input || '');
      setAiFeedback(savedJourney.mistValley.feedback || '');
    }
  }, []);

  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newLang = e.target.value as LanguageCode;
    localStorage.setItem('lang', newLang);
    setLang(newLang);
  };

  const handleSubmit = async () => {
    if (!userInput.trim()) return;

    setIsLoading(true);
    setAiFeedback('');

    try {
      const response = await fetch('/api/coach/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: userInput }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      const feedback = data.feedback;

      setAiFeedback(feedback);

      // 解鎖成就並儲存進度
      setUnlockedBadges(prev => [...new Set([...prev, 'MIST_VALLEY_COMPLETED'])]);
      const journeyData = {
        mistValley: {
          completed: true,
          input: userInput,
          feedback: feedback,
        }
      };
      localStorage.setItem('userJourney', JSON.stringify(journeyData));

    } catch (error) {
      console.error('Failed to fetch AI feedback:', error);
      // Fallback in case of network/server error
      setAiFeedback('抱歉，與教練的連線暫時中斷。請稍後再試。');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      {/* 頂部導覽列 */}
      <div style={{position:'absolute',top:0,left:0,width:'100%',zIndex:100,display:'flex',justifyContent:'space-between',alignItems:'center',padding:'18px 32px 0 32px',boxSizing:'border-box',background:'transparent'}}>
        <button className="topbar-btn" onClick={()=>navigate('/')} style={{fontWeight:700,fontSize:18,padding:'6px 16px',borderRadius:8,border:'1.5px solid #6B5BFF',background:'#fff',color:'#6B5BFF',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s'}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>{t.backToHome}</button>
        <div style={{display:'flex',gap:12,marginRight:8}}>
          <button className="topbar-btn" onClick={async()=>{await signOut(auth);localStorage.clear();window.location.href='/'}} style={{fontWeight:700,fontSize:18,padding:'6px 16px',borderRadius:8,border:'1.5px solid #6B5BFF',background:'#fff',color:'#6B5BFF',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s'}} onMouseOver={e=>{e.currentTarget.style.background='#6B5BFF';e.currentTarget.style.color='#fff';}} onMouseOut={e=>{e.currentTarget.style.background='#fff';e.currentTarget.style.color='#6B5BFF';}}>{t.logout}</button>
          <select className="topbar-select" value={lang} onChange={handleLanguageChange} style={{padding:'6px 14px',borderRadius:8,fontWeight:600,border:'1.5px solid #6B5BFF',color:'#6B5BFF',background:'#fff',cursor:'pointer',transition:'background 0.18s, color 0.18s, border 0.18s'}} onMouseOver={e=>{(e.target as HTMLSelectElement).style.background='#6B5BFF';(e.target as HTMLSelectElement).style.color='#fff';}} onMouseOut={e=>{(e.target as HTMLSelectElement).style.background='#fff';(e.currentTarget as HTMLSelectElement).style.color='#6B5BFF';}}>
            {LANGS.map(l => <option key={l.code} value={l.code}>{l.label}</option>)}
          </select>
        </div>
      </div>

      {/* 主內容區 */}
      <div className="modern-bg" style={{ background: `url('/valley.png') center center / cover no-repeat`, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        <div style={{ width: '100%', maxWidth: 720, background: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(10px)', borderRadius: 24, padding: '32px 40px', boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2)', position: 'relative' }}>

          {/* 標題區 */}
          <div style={{ textAlign: 'center', marginBottom: 24 }}>
            <h1 style={{ fontSize: 36, fontWeight: 900, color: '#2c3e50', margin: 0 }}>{t.pathTitle}</h1>
            <p style={{ fontSize: 18, color: '#34495e', marginTop: 4 }}>{t.pathSubtitle}</p>
          </div>

          {/* 任務區 */}
          <div style={{ background: '#ecf0f1', borderRadius: 16, padding: 24 }}>
            <h2 style={{ fontSize: 24, fontWeight: 700, color: '#2980b9', borderBottom: '2px solid #3498db', paddingBottom: 8, marginBottom: 16 }}>{t.stage1Title}</h2>
            <p style={{ fontSize: 16, color: '#34495e', lineHeight: 1.6 }}>{t.stage1Mission}</p>
            <textarea
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              disabled={isLoading || unlockedBadges.includes('MIST_VALLEY_COMPLETED')}
              placeholder='在這裡寫下你的故事...'
              style={{
                width: '100%',
                minHeight: 150,
                padding: 16,
                fontSize: 16,
                borderRadius: 8,
                border: '1px solid #bdc3c7',
                boxSizing: 'border-box',
                marginTop: 12,
                resize: 'vertical',
                background: unlockedBadges.includes('MIST_VALLEY_COMPLETED') ? '#f0f0f0' : '#fff',
              }}
            />
            <button
              onClick={handleSubmit}
              disabled={isLoading || !userInput.trim() || unlockedBadges.includes('MIST_VALLEY_COMPLETED')}
              style={{
                width: '100%',
                padding: '12px 0',
                fontSize: 18,
                fontWeight: 700,
                background: '#3498db',
                color: '#fff',
                border: 'none',
                borderRadius: 8,
                cursor: 'pointer',
                marginTop: 16,
                transition: 'background 0.2s',
                opacity: (isLoading || !userInput.trim() || unlockedBadges.includes('MIST_VALLEY_COMPLETED')) ? 0.6 : 1,
              }}
            >
              {isLoading ? '...' : t.submitButton}
            </button>
          </div>

          {/* AI 教練回覆區 */}
          {(isLoading || aiFeedback) && (
            <div style={{ background: '#f8f9fa', borderRadius: 16, padding: 24, marginTop: 24 }}>
              <h3 style={{ fontSize: 20, fontWeight: 700, color: '#16a085' }}>{t.aiCoach}</h3>
              {isLoading ? (
                <p style={{ fontSize: 16, color: '#555' }}>{t.aiLoading}</p>
              ) : (
                <p style={{ fontSize: 16, color: '#2c3e50', lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{aiFeedback}</p>
              )}
            </div>
          )}

          {/* 勳章牆 */}
          {unlockedBadges.length > 0 && (
             <div style={{ marginTop: 24 }}>
              <h3 style={{ fontSize: 20, fontWeight: 700, color: '#8e44ad', textAlign: 'center' }}>{t.badgeWall}</h3>
              <div style={{ display: 'flex', justifyContent: 'center', gap: 16, marginTop: 12 }}>
                {unlockedBadges.map(badgeKey => {
                  const badge = BADGES[badgeKey as keyof typeof BADGES];
                  return (
                    <div key={badgeKey} style={{ textAlign: 'center' }}>
                      <span style={{ fontSize: 48, filter: 'drop-shadow(0 4px 6px rgba(0,0,0,0.1))' }}>{badge.icon}</span>
                      <p style={{ margin: '4px 0 0', fontSize: 14, color: '#555' }}>{badge[lang as keyof typeof badge]}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}