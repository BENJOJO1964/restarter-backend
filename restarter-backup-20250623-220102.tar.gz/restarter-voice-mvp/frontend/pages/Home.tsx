import React, { useState, useRef, useLayoutEffect, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import app from '../src/firebaseConfig';
import { getAuth, signOut, onAuthStateChanged } from 'firebase/auth';

type LanguageCode = 'zh-TW' | 'zh-CN' | 'en' | 'ja' | 'ko' | 'th' | 'vi' | 'ms' | 'la';

const LANGS: { code: LanguageCode; label: string }[] = [
  { code: 'zh-TW', label: '繁中' },
  { code: 'zh-CN', label: '简中' },
  { code: 'en', label: 'EN' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'th', label: 'ภาษาไทย' },
  { code: 'vi', label: 'Tiếng Việt' },
  { code: 'ms', label: 'Bahasa Melayu' },
  { code: 'la', label: 'Latīna' },
];

const TEXT: Record<LanguageCode, { slogan: string[]; desc: string; wall: string; friend: string; voice: string; ai: string; tts: string; chat: string; emotion: string; }> = {
  'zh-TW': {
    slogan: ['朋友，站出來', '這裡不是只有三、五個人，你絕不孤單！'],
    desc: 'Restarter™世界更生人平台讓你毫無拘束、盡情抒發，陪你被好好聽見。',
    wall: '進入情緒牆（Restart Wall）',
    friend: '交友區',
    voice: '即時語音輸入',
    ai: 'AI 風格回覆',
    tts: '擬真語音輸出',
    chat: '來聊天吧！',
    emotion: '情緒圖像實驗室',
  },
  'zh-CN': {
    slogan: ['朋友，站出来', '这里不是只有三、五个人，你绝不孤单！'],
    desc: 'Restarter™世界更生人平台让你毫无拘束、尽情抒发，陪你被好好听见。',
    wall: '进入情绪墙（Restart Wall）',
    friend: '交友区',
    voice: '即时语音输入',
    ai: 'AI 风格回复',
    tts: '拟真语音输出',
    chat: '来聊天吧！',
    emotion: '情緒圖像實驗室',
  },
  'en': {
    slogan: ['Friend, speak up', 'there are not just a few people here, you are never alone!'],
    desc: 'The Restarter™ global platform for formerly incarcerated individuals allows you to express yourself freely and without restraint, ensuring you are truly heard.',
    wall: 'Enter Restart Wall',
    friend: 'Friend Match',
    voice: 'Voice Input',
    ai: 'AI Style Reply',
    tts: 'Realistic TTS',
    chat: "Let's Chat!",
    emotion: 'Emotion Visual Lab',
  },
  'ja': {
    slogan: ['友よ、声を上げて', 'ここは三、五人だけじゃない、決して孤独じゃない！'],
    desc: 'Restarter™の世界の更生者プラットフォームで、自由に、思う存分気持ちを表現し、あなたの声がしっかりと届くように寄り添います。',
    wall: '感情ウォールへ',
    friend: '友達マッチ',
    voice: '音声入力',
    ai: 'AIスタイル返信',
    tts: 'リアルTTS',
    chat: '話しましょう！',
    emotion: '感情ビジュアルラボ',
  },
  'ko': {
    slogan: ['친구, 목소리를 내세요', '여기는 몇 사람만 있는 게 아니에요, 당신은 결코 혼자가 아니에요!'],
    desc: 'Restarter™ 글로벌 플랫폼은 전과자 개인이 자유롭게 자신을 표현하고 제약 없이, 당신의 목소리가 진정으로 들릴 수 있도록 보장합니다.',
    wall: '재시작의 벽으로 들어가기',
    friend: '친구 매칭',
    voice: '음성 입력',
    ai: 'AI 스타일 답장',
    tts: '현실적인 TTS',
    chat: "채팅하자!",
    emotion: '감정 비주얼 랩',
  },
  'th': {
    slogan: ['เพื่อน, พูดออกมา', 'ที่นี่ไม่ได้มีแค่ไม่กี่คน, คุณไม่เคยโดดเดี่ยว!'],
    desc: 'แพลตฟอร์มระดับโลก Restarter™ สำหรับบุคคลที่เคยถูกจองจำ ช่วยให้คุณแสดงออกอย่างอิสระและไม่มีข้อจำกัด ทำให้มั่นใจได้ว่าเสียงของคุณจะถูกได้ยินอย่างแท้จริง',
    wall: 'เข้าสู่กำแพงรีสตาร์ท',
    friend: 'จับคู่เพื่อน',
    voice: 'ป้อนข้อมูลด้วยเสียง',
    ai: 'ตอบกลับสไตล์ AI',
    tts: 'TTS ที่สมจริง',
    chat: "มาคุยกันเถอะ!",
    emotion: 'ห้องทดลองภาพอารมณ์',
  },
  'vi': {
    slogan: ['Bạn ơi, hãy lên tiếng', 'ở đây không chỉ có vài người, bạn không bao giờ cô đơn!'],
    desc: 'Nền tảng toàn cầu Restarter™ dành cho những người từng bị giam giữ cho phép bạn thể hiện bản thân một cách tự do và không bị gò bó, đảm bảo bạn thực sự được lắng nghe.',
    wall: 'Vào Tường Khởi động lại',
    friend: 'Ghép bạn bè',
    voice: 'Nhập liệu bằng giọng nói',
    ai: 'Trả lời theo phong cách AI',
    tts: 'TTS thực tế',
    chat: "Hãy trò chuyện!",
    emotion: 'Phòng thí nghiệm hình ảnh cảm xúc',
  },
  'ms': {
    slogan: ['Kawan, bersuaralah', 'di sini bukan hanya beberapa orang, anda tidak pernah keseorangan!'],
    desc: 'Platform global Restarter™ untuk individu yang pernah dipenjarakan membolehkan anda meluahkan perasaan anda dengan bebas dan tanpa sekatan, memastikan anda benar-benar didengari.',
    wall: 'Masuk Dinding Mula Semula',
    friend: 'Padanan Rakan',
    voice: 'Input Suara',
    ai: 'Balasan Gaya AI',
    tts: 'TTS Realistik',
    chat: "Jom Sembang!",
    emotion: 'Makmal Visual Emosi',
  },
  'la': {
    slogan: ['Amice, loquere', 'non pauci hic sunt, numquam solus es!'],
    desc: 'Restarter™ suggestus globalis pro singulis quondam incarceratis permittit te libere et sine coercitione te exprimere, ut vere audiatur.',
    wall: 'Intra Murum Restart',
    friend: 'Par Amicus',
    voice: 'Vox Input',
    ai: 'AI Stylus Responsio',
    tts: 'Verus TTS',
    chat: "Loquamur!",
    emotion: 'Emotion Visual Lab',
  },
};

const FRIEND_EMOJI: Record<LanguageCode, string> = {
  'zh-TW': '🧑‍🤝‍🧑',
  'zh-CN': '🧑‍🤝‍🧑',
  'en': '🧑‍🤝‍🧑',
  'ja': '🧑‍🤝‍🧑',
  'ko': '🧑‍🤝‍🧑',
  'th': '🧑‍🤝‍🧑',
  'vi': '🧑‍🤝‍🧑',
  'ms': '🧑‍🤝‍🧑',
  'la': '🧑‍🤝‍🧑',
};

const SLOGAN2: Record<LanguageCode, string> = {
  'zh-TW': '每一位更生人，都是世界的一員！',
  'zh-CN': '每一位更生人，都是世界的一员！',
  'en': 'Everyone deserves a place in the world!',
  'ja': 'すべての更生者は世界の一員です！',
  'ko': '모든 사람은 세상에 있을 자격이 있습니다!',
  'th': 'ทุกคนสมควรได้รับที่ในโลก!',
  'vi': 'Mọi người đều xứng đáng có một vị trí trên thế giới!',
  'ms': 'Setiap orang berhak mendapat tempat di dunia!',
  'la': 'Omnes locum in mundo merentur!',
};

export default function Home() {
  const navigate = useNavigate();
  const [lang, setLang] = useState<LanguageCode>(() => (localStorage.getItem('lang') as LanguageCode) || 'zh-TW');
  useEffect(() => { localStorage.setItem('lang', lang); }, [lang]);
  const t = TEXT[lang];
  const featureBtnsRef = useRef<HTMLDivElement>(null);
  const chatBtnRef = useRef<HTMLButtonElement>(null);
  const [chatBtnMargin, setChatBtnMargin] = useState(0);
  const auth = getAuth(app);
  const [user, setUser] = useState<any>(null);

  useLayoutEffect(() => {
    if (featureBtnsRef.current && chatBtnRef.current) {
      const featureTop = featureBtnsRef.current.getBoundingClientRect().top;
      const chatBtnTop = chatBtnRef.current.getBoundingClientRect().top;
      const featureHeight = featureBtnsRef.current.getBoundingClientRect().height;
      const chatBtnHeight = chatBtnRef.current.getBoundingClientRect().height;
      setChatBtnMargin((featureTop + featureHeight) - (chatBtnTop + chatBtnHeight));
    }
  }, [lang]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => setUser(u));
    return () => unsubscribe();
  }, []);

  const handleFeature = (type: string) => {
    if (type === 'voice') {
      navigate('/voice');
    } else if (type === 'ai') {
      navigate('/ai');
    } else if (type === 'tts') {
      navigate('/tts');
    } else if (type === 'chat') {
      navigate('/chat');
    } else if (type === 'friend') {
      navigate('/friend');
    } else if (type === 'emotion') {
      navigate('/EmotionVisualLab');
    }
  };

  const logoutText = lang === 'zh-TW' ? '登出' : lang === 'zh-CN' ? '登出' : lang === 'ja' ? 'ログアウト' : lang === 'ko' ? '로그아웃' : lang === 'th' ? 'ออกจากระบบ' : lang === 'vi' ? 'Đăng xuất' : lang === 'ms' ? 'Keluar' : 'Logout';

  const MODULES = [
    {
      key: 'journal',
      icon: '🎨',
      title: {
        'zh-TW': '情緒圖像實驗室', 'zh-CN': '情绪图像实验室', 'en': 'Emotion Visual Lab', 'ja': '感情ビジュアルラボ', 'ko': '감정 비주얼 랩', 'th': 'ห้องทดลองภาพอารมณ์', 'vi': 'Phòng thí nghiệm hình ảnh cảm xúc', 'ms': 'Makmal Visual Emosi', 'la': 'Emotion Visual Lab'
      },
      desc: {
        'zh-TW': '用AI生成你的情緒藝術圖像', 'zh-CN': '用AI生成你的情绪艺术图像', 'en': 'Generate your emotion art with AI', 'ja': 'AIで感情アートを生成', 'ko': 'AI로 감정 예술 생성', 'th': 'สร้างงานศิลปะอารมณ์ด้วย AI', 'vi': 'Tạo nghệ thuật cảm xúc bằng AI', 'ms': 'Hasilkan seni emosi anda dengan AI', 'la': 'Genera artem tuam emotionis cum AI'
      },
      path: '/journal'
    },
    {
      key: 'missions',
      icon: '🎯',
      title: {
        'zh-TW': '任務挑戰', 'zh-CN': '任务挑战', 'en': 'Restart Missions', 'ja': 'ミッション挑戦', 'ko': '재시작 임무', 'th': 'ภารกิจรีสตาร์ท', 'vi': 'Nhiệm vụ khởi động lại', 'ms': 'Misi Mula Semula', 'la': 'Restart Missions'
      },
      desc: {
        'zh-TW': 'AI生成日常任務，完成獲徽章', 'zh-CN': 'AI生成日常任务，完成获徽章', 'en': 'AI daily missions, earn badges', 'ja': 'AI日課ミッションでバッジ獲得', 'ko': 'AI 일일 임무, 배지 획득', 'th': 'ภารกิจรายวันของ AI, รับเหรียญตรา', 'vi': 'Nhiệm vụ hàng ngày của AI, kiếm huy hiệu', 'ms': 'Misi harian AI, dapatkan lencana', 'la': 'AI daily missions, earn badges'
      },
      path: '/missions'
    },
    {
      key: 'pairtalk',
      icon: '🤝',
      title: {
        'zh-TW': '配對對聊', 'zh-CN': '配对对聊', 'en': 'PairTalk Match', 'ja': 'ペアトーク', 'ko': '페어토크 매치', 'th': 'จับคู่คู่คุย', 'vi': 'Ghép đôi trò chuyện', 'ms': 'Padanan PairTalk', 'la': 'PairTalk Match'
      },
      desc: {
        'zh-TW': 'AI引導配對，安全對話', 'zh-CN': 'AI引导配对，安全对话', 'en': 'AI-guided matching, safe chat', 'ja': 'AIが導く安全な対話', 'ko': 'AI 안내 매칭, 안전한 대화', 'th': 'การจับคู่ที่แนะนำโดย AI, แชทที่ปลอดภัย', 'vi': 'Ghép nối do AI hướng dẫn, trò chuyện an toàn', 'ms': 'Pemadanan berpandukan AI, sembang selamat', 'la': 'AI-guided matching, safe chat'
      },
      path: '/pairtalk'
    },
    {
      key: 'skillbox',
      icon: '🛠️',
      title: {
        'zh-TW': '情境模擬室', 'zh-CN': '情境模拟室', 'en': 'SkillBox', 'ja': 'スキルボックス', 'ko': '스킬박스', 'th': 'สกิลบ็อกซ์', 'vi': 'Hộp kỹ năng', 'ms': 'Kotak Kemahiran', 'la': 'SkillBox'
      },
      desc: {
        'zh-TW': '練習社會互動，解鎖成就', 'zh-CN': '练习社会互动，解锁成就', 'en': 'Practice social skills, unlock achievements', 'ja': '社会スキル練習で実績解除', 'ko': '사회적 기술 연습, 업적 잠금 해제', 'th': 'ฝึกฝนทักษะทางสังคม, ปลดล็อกความสำเร็จ', 'vi': 'Thực hành kỹ năng xã hội, mở khóa thành tích', 'ms': 'Latih kemahiran sosial, buka pencapaian', 'la': 'Practice social skills, unlock achievements'
      },
      path: '/skillbox'
    }
  ];

  return (
    <>
      <div style={{ position: 'fixed', top: 24, right: 36, zIndex: 9999, display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 18, pointerEvents: 'auto' }}>
        {user ? (
          <button className="topbar-btn" onClick={async () => { await signOut(auth); localStorage.clear(); window.location.href = '/'; }}>{logoutText}</button>
        ) : (
          <button className="topbar-btn" onClick={() => window.location.href = '/register'}>登入</button>
        )}
        <select className="topbar-select" value={lang} onChange={e => { localStorage.setItem('lang', e.target.value as LanguageCode); window.location.href = '/'; }}
          style={{ padding: '6px 18px', borderRadius: 8, fontWeight: 700, border: '2px solid #6B5BFF', color: '#6B5BFF', background: '#fff', cursor: 'pointer', fontSize: 16, transition: 'background 0.2s, color 0.2s, box-shadow 0.2s', boxShadow: 'none' }}
          onMouseOver={e => { e.currentTarget.style.background = '#6B5BFF'; e.currentTarget.style.color = '#fff'; e.currentTarget.style.boxShadow = '0 2px 12px #6B5BFF55'; }}
          onMouseOut={e => { e.currentTarget.style.background = '#fff'; e.currentTarget.style.color = '#6B5BFF'; e.currentTarget.style.boxShadow = 'none'; }}
        >
          {LANGS.map(l => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </div>
      <div style={{ width: '100vw', minHeight: '100vh', background: `url('/plains.png') center center/cover no-repeat`, display: 'flex', flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'center' }}>
        {/* 左側內容：主標題、說明、功能按鈕 */}
        <div className="home-left-col left-relative" style={{ flex: 1, minWidth: 320, maxWidth: 600, display: 'flex', flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'flex-start', padding: '48px 0 0 0', zIndex: 2 }}>
          {/* LOGO、標語、主標題、說明、功能按鈕等原本內容 */}
          <div className="fixed-logo-box" style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <img src="/ctx-logo.png" className="fixed-logo-img" style={{ marginBottom: 0, width: 182, height: 182 }} />
            <div className="fixed-logo-slogan" style={{ marginLeft: 8, whiteSpace: 'nowrap' }}>
              {t.slogan[0]}...{t.slogan[1]}
            </div>
          </div>
          <div className="column-content" style={{ justifyContent: 'center', alignItems: 'center', height: '100%', paddingTop: 48 }}>
            <h1 className="main-title" style={{ position: 'relative', left: '45px', fontSize: 48, fontWeight: 900, color: '#fff', marginBottom: 18, textShadow: '0 2px 12px #232946, 0 4px 24px #0008' }}>Restarter™ Global Platform</h1>
            <div className="main-desc" style={{ color: '#fff', fontSize: 22, marginBottom: 12, textAlign: 'center', maxWidth: 480, fontWeight: 700, textShadow: '0 2px 12px #232946, 0 4px 24px #0008' }}>
              <span style={{ color: '#fff', fontWeight: 900, textShadow: '0 2px 12px #232946, 0 4px 24px #0008' }}>Restarter™</span>{t.desc.replace('Restarter™', '')}
            </div>
            <div style={{ color: '#fff', fontSize: 16, textAlign: 'center', marginBottom: 24, fontWeight: 700, textShadow: '0 2px 12px #232946, 0 4px 24px #0008' }}>{lang==='zh-TW'?'你怎麼想都可以說、寫出來，這裡沒有對與錯 💡':lang==='zh-CN'?'你怎么想都可以说、写出来，这里没有对与错 💡':lang==='ja'?'何を思っても話したり書いたりしていい、ここに正解も間違いもない 💡':'You can say or write whatever you think, there is no right or wrong here 💡'}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18, marginBottom: 18, justifyContent: 'center', width: '100%' }}>
              <div style={{ display: 'flex', flexDirection: 'row', gap: 18, justifyContent: 'center' }}>
                <button className="feature-btn" style={{ fontSize: 18, padding: '18px 24px', minWidth: 160, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }} onClick={() => navigate('/friend')}>
                  <span style={{ fontSize: 32 }}>{FRIEND_EMOJI[lang]}</span>
                  <span style={{ fontWeight: 700 }}>{t.friend}</span>
                  <span style={{ fontSize: 14, color: '#614425', marginTop: 2, fontWeight: 500 }}>{lang === 'zh-TW' ? '尋找新朋友，建立支持圈' : lang === 'zh-CN' ? '寻找新朋友，建立支持圈' : lang === 'en' ? 'Find new friends, build your support circle' : '新しい友達を探そう'} 😊</span>
                </button>
                {MODULES.slice(0,2).map(m => (
                  <button key={m.key} className="feature-btn" style={{ fontSize: 18, padding: '18px 24px', minWidth: 160, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }} onClick={() => navigate(m.path)}>
                    <span style={{ fontSize: 32 }}>{m.icon}</span>
                    <span style={{ fontWeight: 700 }}>{m.title[lang]}</span>
                    <span style={{ fontSize: 14, color: '#614425', marginTop: 2, fontWeight: 500 }}>{m.desc[lang]} 😊</span>
                  </button>
                ))}
              </div>
              <div style={{ display: 'flex', flexDirection: 'row', gap: 18, justifyContent: 'center' }}>
                {MODULES.slice(2).map(m => (
                  <button key={m.key} className="feature-btn" style={{ fontSize: 18, padding: '18px 24px', minWidth: 160, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }} onClick={() => navigate(m.path)}>
                    <span style={{ fontSize: 32 }}>{m.icon}</span>
                    <span style={{ fontWeight: 700 }}>{m.title[lang]}</span>
                    <span style={{ fontSize: 14, color: '#614425', marginTop: 2, fontWeight: 500 }}>{m.desc[lang]} 😊</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
        {/* 右側內容：mockup 圖片和來聊天吧按鈕 */}
        <div className="home-right-col" style={{ flex: 1, minWidth: 320, maxWidth: 520, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start', paddingTop: 120, zIndex: 2 }}>
          <img src="/hero-mic.jpg" className="home-mic-img" style={{ marginBottom: 0, height: 'calc(100vh - 180px)', maxHeight: 520, minHeight: 320, width: '100%', objectFit: 'contain', background: '#232946' }} />
          <button
            ref={chatBtnRef}
            className="feature-btn home-chat-btn"
            style={{ height: 64, marginTop: 0, marginBottom: 0, position: 'relative', top: '-32px', gap: 4 }}
            onClick={() => handleFeature('chat')}
          >
            <span role="img" aria-label="chat" style={{ marginRight: 2, fontSize: 22 }}>💬</span>
            <span className="home-chat-btn-text">{t.chat}</span>
          </button>
        </div>
      </div>
      <style>{`
        .feature-btn, .home-chat-btn, .topbar-btn {
          transition: background 0.18s, color 0.18s, box-shadow 0.18s;
          cursor: pointer;
        }
        .feature-btn:hover, .home-chat-btn:hover, .topbar-btn:hover {
          background: #4a3bbf !important;
          color: #fff !important;
          box-shadow: 0 2px 12px #6B5BFF55;
        }
        .feature-btn, .home-chat-btn {
          background: #fff;
          border-radius: 12px;
          border: 2px solid #6B5BFF;
          color: #6B5BFF;
          font-weight: 700;
          font-size: 16px;
          padding: 8px 16px;
        }
        .home-chat-btn-text {
          font-size: 18px;
          margin-left: 2px;
        }
        .topbar-btn {
          background: #6c63ff;
          border-radius: 8px;
          border: none;
          color: #fff;
          font-weight: 700;
          font-size: 16px;
          padding: 8px 18px;
        }
        .fixed-logo-box {
          position: fixed;
          top: 16px;
          left: 42px;
          display: flex;
          align-items: center;
          gap: 12px;
          z-index: 10000;
        }
        .fixed-logo-img {
          width: 54px;
          height: 54px;
        }
        .fixed-logo-slogan {
          font-size: 20px;
          font-weight: 700;
          color: #fff;
          text-shadow: 0 2px 8px #232946, 0 4px 18px #0008;
        }
      `}</style>
    </>
  );
}