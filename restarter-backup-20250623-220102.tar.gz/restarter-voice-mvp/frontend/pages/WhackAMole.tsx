import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

// --- Types ---
export interface Mole {
  id: string;
  name: string;
  image: string;
}

export interface PhraseBank {
  praise: string[];
  taunt: string[];
  severeTaunt: string[];
}

type LanguageCode = 'zh-TW' | 'zh-CN' | 'en' | 'ja' | 'ko' | 'vi' | 'th' | 'la' | 'ms';

const LANGS: { code: LanguageCode; label: string }[] = [
  { code: 'zh-TW', label: '繁中' },
  { code: 'zh-CN', label: '简中' },
  { code: 'en', label: 'EN' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'vi', label: 'Tiếng Việt' },
  { code: 'th', label: 'ไทย' },
  { code: 'la', label: 'Latīna' },
  { code: 'ms', label: 'Bahasa Melayu' },
];

const TEXTS: Record<LanguageCode, { title: string; loading: string; error: string; tryAgain: string; selectTime: string; thirty: string; sixty: string; ninety: string; timeUp: string; yourScore: string; duration: string; playAgain: string; seconds: string; }> = {
    'zh-TW': { title: "打爆你", loading: "正在加載遊戲...", error: "加載遊戲資源失敗", tryAgain: "沒有成功加載遊戲資源，請刷新頁面重試。", selectTime: "選擇遊戲時長", thirty: "30秒", sixty: "60秒", ninety: "90秒", timeUp: "時間到！", yourScore: "你的分數", duration: "遊戲時長", playAgain: "再玩一次", seconds: "秒" },
    'zh-CN': { title: "打爆你", loading: "正在加载游戏...", error: "加载游戏资源失败", tryAgain: "没有成功加载游戏资源，请刷新页面重试。", selectTime: "选择游戏时长", thirty: "30秒", sixty: "60秒", ninety: "90秒", timeUp: "时间到！", yourScore: "你的分数", duration: "游戏时长", playAgain: "再玩一次", seconds: "秒" },
    'en': { title: "Whack the Bastards", loading: "Loading game...", error: "Failed to load game assets", tryAgain: "Failed to load game assets, please refresh and try again.", selectTime: "Select Game Duration", thirty: "30 Seconds", sixty: "60 Seconds", ninety: "90 Seconds", timeUp: "Time's Up!", yourScore: "Your Score", duration: "Duration", playAgain: "Play Again", seconds: "s" },
    'ja': { title: "やつらを叩け", loading: "ゲームを読み込み中...", error: "ゲームアセットの読み込みに失敗しました", tryAgain: "ゲームアセットの読み込みに失敗しました。リフレッシュして再試行してください。", selectTime: "ゲーム時間を選択", thirty: "30秒", sixty: "60秒", ninety: "90秒", timeUp: "時間切れ！", yourScore: "スコア", duration: "ゲーム時間", playAgain: "もう一度プレイ", seconds: "秒" },
    'ko': { title: "녀석들을 때려잡아라", loading: "게임 로딩 중...", error: "게임 자산을 불러오지 못했습니다", tryAgain: "게임 자산을 불러오지 못했습니다. 새로고침 후 다시 시도해주세요.", selectTime: "게임 시간 선택", thirty: "30초", sixty: "60초", ninety: "90초", timeUp: "시간 종료!", yourScore: "점수", duration: "게임 시간", playAgain: "다시 플레이", seconds: "초" },
    'vi': { title: "Đập tan lũ khốn", loading: "Đang tải trò chơi...", error: "Tải tài nguyên trò chơi thất bại", tryAgain: "Tải tài nguyên trò chơi thất bại, vui lòng làm mới và thử lại.", selectTime: "Chọn thời gian chơi", thirty: "30 giây", sixty: "60 giây", ninety: "90 giây", timeUp: "Hết giờ!", yourScore: "Điểm của bạn", duration: "Thời gian", playAgain: "Chơi lại", seconds: "giây" },
    'th': { title: "ทุบหัวพวกมันซะ", loading: "กำลังโหลดเกม...", error: "โหลดทรัพยากรเกมล้มเหลว", tryAgain: "โหลดทรัพยากรเกมล้มเหลว กรุณารีเฟรชแล้วลองอีกครั้ง", selectTime: "เลือกเวลาเล่น", thirty: "30 วินาที", sixty: "60 วินาที", ninety: "90 วินาที", timeUp: "หมดเวลา!", yourScore: "คะแนนของคุณ", duration: "ระยะเวลา", playAgain: "เล่นอีกครั้ง", seconds: "วินาที" },
    'la': { title: "Percute Scelestos", loading: "Ludum onerans...", error: "Deficio onerare ludum bonorum", tryAgain: "Deficio onerare ludum bonorum, quaeso refice et iterum conare.", selectTime: "Elige Ludum Duratio", thirty: "30 Secundas", sixty: "60 Secundas", ninety: "90 Secundas", timeUp: "Tempus Est!", yourScore: "Tuum Score", duration: "Duratio", playAgain: "Iterum Lude", seconds: "s" },
    'ms': { title: "Hentam Si Jahat", loading: "Memuatkan permainan...", error: "Gagal memuatkan aset permainan", tryAgain: "Gagal memuatkan aset permainan, sila muat semula dan cuba lagi.", selectTime: "Pilih Tempoh Permainan", thirty: "30 Saat", sixty: "60 Saat", ninety: "90 Saat", timeUp: "Masa Tamat!", yourScore: "Skor Anda", duration: "Tempoh", playAgain: "Main Lagi", seconds: "s" }
};

// --- Hole Component ---
interface HoleProps {
  mole: Mole | null;
  onClick: () => void;
  isPeeking: boolean;
}

const Hole: React.FC<HoleProps> = ({ mole, onClick, isPeeking }) => (
  <div className={`hole ${isPeeking ? 'up' : ''}`} onClick={onClick}>
    {mole && <img src={mole.image} alt={mole.name} className="mole-image" />}
  </div>
);

// --- Game Component ---
interface GameProps {
  moles: Mole[];
  phrases: PhraseBank;
  duration: number;
  onGameEnd: (score: number) => void;
}

const Game: React.FC<GameProps> = ({ moles, phrases, duration, onGameEnd }) => {
  const [score, setScore] = useState(0);
  const [holes, setHoles] = useState<(Mole | null)[]>(new Array(9).fill(null));
  const [isGameRunning, setIsGameRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(duration);
  const [feedback, setFeedback] = useState('');

  const hitCount = useRef(0);
  const missCount = useRef(0);
  const totalMoles = useRef(0);
  const level = useRef(1);
  const timers = useRef<(NodeJS.Timeout | null)[]>([]);

  const showFeedback = (text: string) => {
    setFeedback(text);
    setTimeout(() => setFeedback(''), 1000);
  };
  
  const getRandomPhrase = (type: keyof PhraseBank) => phrases[type][Math.floor(Math.random() * phrases[type].length)];

  const updateLevel = () => {
    const accuracy = totalMoles.current > 0 ? hitCount.current / totalMoles.current : 0;
    if (accuracy > 0.9 && level.current < 6) {
      level.current++;
      showFeedback(`升級！LV ${level.current} - ${getRandomPhrase('praise')}`);
    } else if (accuracy <= 0.4 && level.current > 1) {
      level.current--;
      showFeedback(`降級！LV ${level.current}`);
    }
  };

  const peek = useCallback(() => {
    if (!isGameRunning) return;
    const time = Math.max(200, 1000 - level.current * 100);
    const holeIndex = Math.floor(Math.random() * 9);
    
    if (holes[holeIndex]) {
        peek();
        return;
    }; 

    totalMoles.current++;
    const randomMole = moles[Math.floor(Math.random() * moles.length)];
    
    setHoles(prev => {
        const newHoles = [...prev];
        newHoles[holeIndex] = randomMole;
        return newHoles;
    });

    const timeoutId = setTimeout(() => {
      setHoles(prev => {
        const newHoles = [...prev];
        if (newHoles[holeIndex]) { // if mole is still there (wasn't hit)
          missCount.current++;
          updateLevel();
          showFeedback(getRandomPhrase(level.current <=1 ? 'severeTaunt' : 'taunt'));
        }
        newHoles[holeIndex] = null;
        return newHoles;
      });
      timers.current[holeIndex] = null;
      peek(); // Next mole
    }, time);

    timers.current[holeIndex] = timeoutId;
  }, [isGameRunning, holes, moles, phrases]);

  const bonk = (index: number) => {
    if (!holes[index]) return; // Cannot bonk an empty hole

    const timeout = timers.current[index];
    if (timeout) {
      clearTimeout(timeout);
      timers.current[index] = null;
    }
    
    hitCount.current++;
    setScore(prev => prev + 1);
    updateLevel();
    showFeedback(getRandomPhrase('praise'));
    
    setHoles(prev => {
        const newHoles = [...prev];
        newHoles[index] = null;
        return newHoles;
    });
    peek(); // Speed up next mole appearance
  };

  useEffect(() => {
    setIsGameRunning(true);
    setTimeLeft(duration);
    setScore(0);
    hitCount.current = 0;
    missCount.current = 0;
    totalMoles.current = 0;
    level.current = 1;

    for (let i = 0; i < 3; i++) { // Start with 3 moles
      peek();
    }

    const gameTimer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(gameTimer);
          setIsGameRunning(false);
          timers.current.forEach(timer => {
            if (timer) clearTimeout(timer);
          });
          onGameEnd(score);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      clearInterval(gameTimer);
      timers.current.forEach(t => t && clearTimeout(t));
    };
  }, [duration, onGameEnd, peek]);

  return (
    <div className="game">
       <div className="game-info">
        <span>分數: {score}</span>
        <span>時間: {timeLeft}s</span>
        <span>等級: {level.current}</span>
      </div>
      {feedback && <div className="feedback">{feedback}</div>}
      <div className="hole-grid">
        {holes.map((mole, i) => (
          <Hole key={i} mole={mole} onClick={() => bonk(i)} isPeeking={!!mole} />
        ))}
      </div>
    </div>
  );
};

// --- WhackAMole Page Component ---
const WhackAMole: React.FC = () => {
  const [moles, setMoles] = useState<Mole[]>([]);
  const [phrases, setPhrases] = useState<PhraseBank | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [duration, setDuration] = useState<number | null>(null);
  const [finalScore, setFinalScore] = useState<number | null>(null);
  const [gameKey, setGameKey] = useState(0);
  const [lang, setLang] = useState<LanguageCode>(() => (localStorage.getItem('lang') as LanguageCode) || 'zh-TW');
  const t = TEXTS[lang] || TEXTS['en'];

  useEffect(() => {
    const savedLang = localStorage.getItem('lang') as LanguageCode;
    if (savedLang && TEXTS[savedLang]) {
      setLang(savedLang);
    }
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        const molesResponse = await fetch('/moles.json');
        if (!molesResponse.ok) throw new Error(`HTTP error! status: ${molesResponse.status}`);
        const molesData = await molesResponse.json();
        setMoles(molesData);

        const phrasesResponse = await fetch('/phrases.json');
        if (!phrasesResponse.ok) throw new Error(`HTTP error! status: ${phrasesResponse.status}`);
        const phrasesData = await phrasesResponse.json();
        setPhrases(phrasesData);
      } catch (e) {
        setError(e instanceof Error ? `${t.error}: ${e.message}` : String(t.error));
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [t.error]);

  const handleGameEnd = (score: number) => {
    setFinalScore(score);
  };
  
  const handleRestart = () => {
      setDuration(null);
      setFinalScore(null);
      setGameKey(prev => prev + 1);
  };
  
  const renderContent = () => {
    if (loading) return <div>{t.loading}</div>;
    if (error) return <div>{t.tryAgain}</div>;

    if (finalScore !== null && duration !== null) {
        return (
            <div className="endscreen">
                <h2>{t.timeUp}</h2>
                <p>{t.yourScore}: {finalScore}</p>
                <p>{t.duration}: {duration} {t.seconds}</p>
                <button onClick={handleRestart}>{t.playAgain}</button>
            </div>
        );
    }

    if (!duration) {
      return (
        <div className="start-screen">
          <h1>{t.title}</h1>
          <h3>{t.selectTime}</h3>
          <div className="duration-options">
            <button onClick={() => setDuration(30)}>{t.thirty}</button>
            <button onClick={() => setDuration(60)}>{t.sixty}</button>
            <button onClick={() => setDuration(90)}>{t.ninety}</button>
          </div>
        </div>
      );
    }
    
    if (moles.length > 0 && phrases) {
      return <Game key={gameKey} moles={moles} phrases={phrases} duration={duration} onGameEnd={handleGameEnd} />;
    }

    return null;
  };

  return (
    <div className="whack-a-mole-container">
       <div style={{ position: 'absolute', top: 24, right: 36, zIndex: 100 }}>
        <select value={lang} onChange={e => {setLang(e.target.value as LanguageCode); localStorage.setItem('lang', e.target.value);}} style={{ padding: '6px 14px', borderRadius: 8, fontWeight: 600 }}>
          {LANGS.map(l => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </div>
      {renderContent()}
    </div>
  );
};

export default WhackAMole;