import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAuth, createUserWithEmailAndPassword, updateProfile, signInWithEmailAndPassword } from 'firebase/auth';
import app from '../src/firebaseConfig';

const auth = getAuth(app);

const TEXT = {
  'zh-TW': {
    heroLeftTop: '救贖不是罪，',
    heroLeftMain: '只是走錯太久。',
    heroLeftSub: '',
    heroLeftYellow: '野花昂首盡綻放！',
    heroRightTop: '我要重新開始...',
    heroRightMain: '每一次的經歷，都是獨一無二的篇章',
    heroRightSub: '而不是成長的絆腳石。',
    heroRightYellow: '從灰燼中重生！',
    title: 'Restarter™ 註冊',
    email: '電子郵件 *必填',
    password: '密碼 (至少8位，含英文及數字) *必填',
    nickname: '暱稱 (2-16字) *必填',
    age: '年齡 *必填',
    selectAge: '請選擇年齡區間',
    country: '國家/地區 *必填',
    city: '城市 (可選)',
    interest: '興趣 *必填',
    eventType: '經歷事件 *必填',
    whatToImprove: '想改善什麼 *必填',
    uploadAvatar: '上傳頭像',
    male: '男',
    female: '女',
    genderRequired: '(必選)',
    register: '🚀 註冊',
    registering: '註冊中...',
    errorAvatar: '請上傳頭像',
    errorGender: '請選擇性別',
    errorEmailFormat: '電子郵件格式無效',
    errorPasswordFormat: '密碼必須至少8個字符，且包含字母和數字',
    errorNicknameFormat: '暱稱必須是2-16個字符',
    errorAgeFormat: '年齡必須在18到99歲之間',
    errorCountry: '請選擇國家/地區',
    errorRegion: '請輸入城市',
    errorInterest: '請選擇興趣',
    errorEventType: '請選擇事件類型',
    errorImprovement: '請選擇想改善的項目',
    formTopSlogan: '而且，更生人雄起沒有錯！',
    login: '登入',
    terms: '條款/聲明',
  },
  'zh-CN': {
    heroLeftTop: '救赎不是罪，',
    heroLeftMain: '只是走错太久。',
    heroLeftSub: '',
    heroLeftYellow: '野花昂首尽绽放！',
    heroRightTop: '我要重新开始...',
    heroRightMain: '每一次的经历，都是独一无二的篇章',
    heroRightSub: '而不是成长的绊脚石。',
    heroRightYellow: '从灰烬中重生！',
    title: 'Restarter™ 注册',
    email: '电子邮件 *必填',
    password: '密码 (至少8位，含英文及数字) *必填',
    nickname: '昵称 (2-16字) *必填',
    age: '年龄 *必填',
    selectAge: '请选择年龄区间',
    country: '国家/地区 *必填',
    city: '城市 (可选)',
    interest: '兴趣 *必填',
    eventType: '经历事件 *必填',
    whatToImprove: '想改善什么 *必填',
    uploadAvatar: '上传头像',
    male: '男',
    female: '女',
    genderRequired: '(必选)',
    register: '🚀 注册',
    registering: '注册中...',
    errorAvatar: '请上传头像',
    errorGender: '请选择性别',
    errorEmailFormat: '电子邮件格式无效',
    errorPasswordFormat: '密码必须至少8个字符，且包含字母和数字',
    errorNicknameFormat: '昵称必须是2-16个字符',
    errorAgeFormat: '年龄必须在18到99岁之间',
    errorCountry: '请选择国家/地区',
    errorRegion: '请输入城市',
    errorInterest: '请选择兴趣',
    errorEventType: '请选择事件类型',
    errorImprovement: '请选择想改善的项目',
    formTopSlogan: '而且，更生人雄起没有错！',
    login: '登录',
    terms: '条款/声明',
  },
  'en': {
    heroLeftTop: 'Redemption is not a crime,',
    heroLeftMain: 'just went down the wrong path for too long.',
    heroLeftSub: '',
    heroLeftYellow: 'Wildflowers bloom bravely!',
    heroRightTop: 'I want a new start...',
    heroRightMain: 'Every experience is a unique chapter,',
    heroRightSub: 'not a barrier to growth.',
    heroRightYellow: 'Rise from the ashes!',
    title: 'Restarter™ Registration',
    email: 'Email *required',
    password: 'Password (min 8 chars, letter & number) *required',
    nickname: 'Nickname (2-16 chars) *required',
    age: 'Age *required',
    selectAge: 'Select age range',
    country: 'Country (Region) *required',
    city: 'City (optional)',
    interest: 'Interest *required',
    eventType: 'History Event *required',
    whatToImprove: 'What to improve *required',
    uploadAvatar: 'Upload Avatar',
    male: 'Male',
    female: 'Female',
    genderRequired: '(*required)',
    register: '🚀 Register',
    registering: 'Registering...',
    errorAvatar: 'Please upload an avatar.',
    errorGender: 'Please select a gender.',
    errorEmailFormat: 'Invalid email format.',
    errorPasswordFormat: 'Password must be at least 8 characters long and contain both letters and numbers.',
    errorNicknameFormat: 'Nickname must be 2-16 characters long.',
    errorAgeFormat: 'Age must be between 18 and 99.',
    errorCountry: 'Please select a country.',
    errorRegion: 'Please enter a city.',
    errorInterest: 'Please select an interest.',
    errorEventType: 'Please select an event type.',
    errorImprovement: 'Please select an item to improve.',
    formTopSlogan: "It's not wrong to rise up!",
    login: 'Login',
    terms: 'Terms/Statement',
  },
  'ja': {
    heroLeftTop: '贖いは罪ではない、',
    heroLeftMain: 'ただ道に迷った時間が長すぎただけだ。',
    heroLeftSub: '',
    heroLeftYellow: '野の花も堂々と咲く！',
    heroRightTop: '私は新しく始めたい...',
    heroRightMain: '一つ一つの経験が、ユニークな章であり、',
    heroRightSub: '成長の障害ではない。',
    heroRightYellow: '灰の中から蘇れ！',
    title: 'Restarter™ 登録',
    email: 'メールアドレス *必須',
    password: 'パスワード (8文字以上、英数字を含む) *必須',
    nickname: 'ニックネーム (2-16文字) *必須',
    age: '年齢 *必須',
    selectAge: '年齢層を選択',
    country: '国/地域 *必須',
    city: '都市 (任意)',
    interest: '興味 *必須',
    eventType: '経験した出来事 *必須',
    whatToImprove: '改善したいこと *必須',
    uploadAvatar: 'アバターをアップロード',
    male: '男性',
    female: '女性',
    genderRequired: '(*必須)',
    register: '🚀 登録',
    registering: '登録中...',
    errorAvatar: 'アバターをアップロードしてください。',
    errorGender: '性別を選択してください。',
    errorEmailFormat: '無効なメール形式です。',
    errorPasswordFormat: 'パスワードは8文字以上で、文字と数字の両方を含める必要があります。',
    errorNicknameFormat: 'ニックネームは2～16文字である必要があります。',
    errorAgeFormat: '年齢は18歳から99歳の間でなければなりません。',
    errorCountry: '国を選択してください。',
    errorRegion: '都市を入力してください。',
    errorInterest: '興味を選択してください。',
    errorEventType: 'イベントタイプを選択してください。',
    errorImprovement: '改善したい項目を選択してください。',
    formTopSlogan: '立ち上がることは間違いじゃない！',
    login: 'ログイン',
    terms: '規約/声明',
  },
  'ko': {
    heroLeftTop: '구원은 죄가 아니며,',
    heroLeftMain: '그저 너무 오랫동안 길을 잃었을 뿐이다.',
    heroLeftSub: '',
    heroLeftYellow: '들꽃은 용감하게 핀다!',
    heroRightTop: '새로운 시작을 원해...',
    heroRightMain: '모든 경험은 독특한 장이며,',
    heroRightSub: '성장의 장벽이 아니다.',
    heroRightYellow: '잿더미에서 일어나라!',
    title: 'Restarter™ 회원가입',
    email: '이메일 *필수',
    password: '비밀번호 (최소 8자, 영문/숫자 포함) *필수',
    nickname: '닉네임 (2-16자) *필수',
    age: '나이 *필수',
    selectAge: '연령대 선택',
    country: '국가/지역 *필수',
    city: '도시 (선택 사항)',
    interest: '관심사 *필수',
    eventType: '경험한 사건 *필수',
    whatToImprove: '개선하고 싶은 점 *필수',
    uploadAvatar: '아바타 업로드',
    male: '남성',
    female: '여성',
    genderRequired: '(*필수)',
    register: '🚀 가입하기',
    registering: '가입 중...',
    errorAvatar: '아바타를 업로드해주세요.',
    errorGender: '성별을 선택해주세요.',
    errorEmailFormat: '유효하지 않은 이메일 형식입니다.',
    errorPasswordFormat: '비밀번호는 최소 8자 이상이며, 문자와 숫자를 모두 포함해야 합니다.',
    errorNicknameFormat: '닉네임은 2-16자여야 합니다.',
    errorAgeFormat: '나이는 18세에서 99세 사이여야 합니다.',
    errorCountry: '국가를 선택해주세요.',
    errorRegion: '도시를 입력해주세요.',
    errorInterest: '관심사를 선택해주세요.',
    errorEventType: '사건 유형을 선택해주세요.',
    errorImprovement: '개선할 항목을 선택해주세요.',
    formTopSlogan: '일어서는 것은 잘못이 아니야!',
    login: '로그인',
    terms: '약관/성명서',
  },
  'th': {
    heroLeftTop: 'การไถ่บาปไม่ใช่ความผิด',
    heroLeftMain: 'เพียงแค่หลงทางมานานเกินไป',
    heroLeftSub: '',
    heroLeftYellow: 'ดอกไม้ป่าบานอย่างกล้าหาญ!',
    heroRightTop: 'ฉันต้องการเริ่มต้นใหม่...',
    heroRightMain: 'ทุกประสบการณ์คือบทที่พิเศษ',
    heroRightSub: 'ไม่ใช่อุปสรรคต่อการเติบโต',
    heroRightYellow: 'ลุกขึ้นจากเถ้าถ่าน!',
    title: 'Restarter™ ลงทะเบียน',
    email: 'อีเมล *จำเป็น',
    password: 'รหัสผ่าน (ขั้นต่ำ 8 ตัวอักษร, ประกอบด้วยตัวอักษรและตัวเลข) *จำเป็น',
    nickname: 'ชื่อเล่น (2-16 ตัวอักษร) *จำเป็น',
    age: 'อายุ *จำเป็น',
    selectAge: 'เลือกช่วงอายุ',
    country: 'ประเทศ/ภูมิภาค *จำเป็น',
    city: 'เมือง (ไม่บังคับ)',
    interest: 'ความสนใจ *จำเป็น',
    eventType: 'เหตุการณ์ที่ผ่านมา *จำเป็น',
    whatToImprove: 'สิ่งที่ต้องการปรับปรุง *จำเป็น',
    uploadAvatar: 'อัปโหลดรูปภาพ',
    male: 'ชาย',
    female: 'หญิง',
    genderRequired: '(*จำเป็น)',
    register: '🚀 ลงทะเบียน',
    registering: 'กำลังลงทะเบียน...',
    errorAvatar: 'กรุณาอัปโหลดรูปโปรไฟล์',
    errorGender: 'กรุณาเลือกเพศ',
    errorEmailFormat: 'รูปแบบอีเมลไม่ถูกต้อง',
    errorPasswordFormat: 'รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษรและมีทั้งตัวอักษรและตัวเลข',
    errorNicknameFormat: 'ชื่อเล่นต้องมีความยาว 2-16 ตัวอักษร',
    errorAgeFormat: 'อายุต้องอยู่ระหว่าง 18 ถึง 99 ปี',
    errorCountry: 'กรุณาเลือกประเทศ',
    errorRegion: 'กรุณากรอกเมือง',
    errorInterest: 'กรุณาเลือกความสนใจ',
    errorEventType: 'กรุณาเลือกประเภทเหตุการณ์',
    errorImprovement: 'กรุณาเลือกรายการที่ต้องการปรับปรุง',
    formTopSlogan: 'การลุกขึ้นสู้ไม่ใช่เรื่องผิด!',
    login: 'เข้าสู่ระบบ',
    terms: 'ข้อกำหนด/คำชี้แจง',
  },
  'vi': {
    heroLeftTop: 'Sự chuộc lỗi không phải là tội ác,',
    heroLeftMain: 'chỉ là đi sai đường quá lâu.',
    heroLeftSub: '',
    heroLeftYellow: 'Hoa dại nở rộ dũng cảm!',
    heroRightTop: 'Tôi muốn một khởi đầu mới...',
    heroRightMain: 'Mỗi trải nghiệm là một chương độc đáo,',
    heroRightSub: 'Không phải là rào cản cho sự phát triển.',
    heroRightYellow: 'Vươn lên từ đống tro tàn!',
    title: 'Đăng ký Restarter™',
    email: 'Email *bắt buộc',
    password: 'Mật khẩu (tối thiểu 8 ký tự, gồm chữ và số) *bắt buộc',
    nickname: 'Biệt danh (2-16 ký tự) *bắt buộc',
    age: 'Tuổi *bắt buộc',
    selectAge: 'Chọn độ tuổi',
    country: 'Quốc gia/Khu vực *bắt buộc',
    city: 'Thành phố (tùy chọn)',
    interest: 'Sở thích *bắt buộc',
    eventType: 'Sự kiện đã trải qua *bắt buộc',
    whatToImprove: 'Điều muốn cải thiện *bắt buộc',
    uploadAvatar: 'Tải lên hình đại diện',
    male: 'Nam',
    female: 'Nữ',
    genderRequired: '(*bắt buộc)',
    register: '🚀 Đăng ký',
    registering: 'Đang đăng ký...',
    errorAvatar: 'Vui lòng tải lên ảnh đại diện.',
    errorGender: 'Vui lòng chọn giới tính.',
    errorEmailFormat: 'Định dạng email không hợp lệ.',
    errorPasswordFormat: 'Mật khẩu phải dài ít nhất 8 ký tự và chứa cả chữ cái và số.',
    errorNicknameFormat: 'Biệt danh phải dài từ 2-16 ký tự.',
    errorAgeFormat: 'Tuổi phải từ 18 đến 99.',
    errorCountry: 'Vui lòng chọn một quốc gia.',
    errorRegion: 'Vui lòng nhập thành phố.',
    errorInterest: 'Vui lòng chọn một sở thích.',
    errorEventType: 'Vui lòng chọn một loại sự kiện.',
    errorImprovement: 'Vui lòng chọn một mục để cải thiện.',
    formTopSlogan: 'Vươn lên không phải là sai!',
    login: 'Đăng nhập',
    terms: 'Điều khoản/Tuyên bố',
  },
  'ms': {
    heroLeftTop: 'Penebusan bukanlah jenayah,',
    heroLeftMain: 'hanya tersalah jalan terlalu lama.',
    heroLeftSub: '',
    heroLeftYellow: 'Bunga liar mekar dengan berani!',
    heroRightTop: 'Saya mahu permulaan yang baru...',
    heroRightMain: 'Setiap pengalaman adalah satu bab yang unik,',
    heroRightSub: 'bukan penghalang kepada pertumbuhan.',
    heroRightYellow: 'Bangkit dari abu!',
    title: 'Pendaftaran Restarter™',
    email: 'E-mel *diperlukan',
    password: 'Kata laluan (min 8 aksara, huruf & nombor) *diperlukan',
    nickname: 'Nama samaran (2-16 aksara) *diperlukan',
    age: 'Umur *diperlukan',
    selectAge: 'Pilih julat umur',
    country: 'Negara/Wilayah *diperlukan',
    city: 'Bandar (pilihan)',
    interest: 'Minat *diperlukan',
    eventType: 'Peristiwa Bersejarah *diperlukan',
    whatToImprove: 'Apa yang ingin diperbaiki *diperlukan',
    uploadAvatar: 'Muat naik gambar profil',
    male: 'Lelaki',
    female: 'Perempuan',
    genderRequired: '(*diperlukan)',
    register: '🚀 Daftar',
    registering: 'Mendaftar...',
    errorAvatar: 'Sila muat naik avatar.',
    errorGender: 'Sila pilih jantina.',
    errorEmailFormat: 'Format e-mel tidak sah.',
    errorPasswordFormat: 'Kata laluan mesti sekurang-kurangnya 8 aksara dan mengandungi kedua-dua huruf dan nombor.',
    errorNicknameFormat: 'Nama samaran mestilah 2-16 aksara.',
    errorAgeFormat: 'Umur mestilah antara 18 dan 99.',
    errorCountry: 'Sila pilih negara.',
    errorRegion: 'Sila masukkan bandar.',
    errorInterest: 'Sila pilih minat.',
    errorEventType: 'Sila pilih jenis acara.',
    errorImprovement: 'Sila pilih item untuk diperbaiki.',
    formTopSlogan: 'Bukan salah untuk bangkit!',
    login: 'Log masuk',
    terms: 'Terma/Penyata',
  },
  'la': { 
    heroLeftTop: 'Redemptio non est crimen,',
    heroLeftMain: 'modo errasse diu.',
    heroLeftSub: '',
    heroLeftYellow: 'Flores feri fortiter efflorescunt!',
    heroRightTop: 'Novum initium volo...',
    heroRightMain: 'Omnis experientia unicum capitulum est,',
    heroRightSub: 'non impedimentum incrementi.',
    heroRightYellow: 'Resurge ex cineribus!',
    title: 'Restarter™ Inscriptio',
    email: 'Email *requiritur',
    password: 'Password (min 8 chars, letter & number) *requiritur',
    nickname: 'Nickname (2-16 chars) *requiritur',
    age: 'Age *requiritur',
    selectAge: 'Selecta aetatis spatium',
    country: 'Country (Region) *requiritur',
    city: 'City (optional)',
    interest: 'Interest *requiritur',
    eventType: 'Historiae Eventus *required',
    whatToImprove: 'Quid emendare vis *required',
    uploadAvatar: 'Upload Avatar',
    male: 'Male',
    female: 'Female',
    genderRequired: '(*required)',
    register: '🚀 Register',
    registering: 'Registering...',
    errorAvatar: 'Please upload an avatar.',
    errorGender: 'Please select a gender.',
    errorEmailFormat: 'Invalid email format.',
    errorPasswordFormat: 'Password must be at least 8 characters long and contain both letters and numbers.',
    errorNicknameFormat: 'Nickname must be 2-16 characters long.',
    errorAgeFormat: 'Age must be between 18 and 99.',
    errorCountry: 'Please select a country.',
    errorRegion: 'Please enter a city.',
    errorInterest: 'Please select an interest.',
    errorEventType: 'Please select an event type.',
    errorImprovement: 'Please select an item to improve.',
    formTopSlogan: 'Surgere non est peccatum!',
    login: 'Inire',
    terms: 'Termini/Declaratio',
  },
};

const LANGS = [
  { code: 'zh-TW', label: '繁體中文' },
  { code: 'zh-CN', label: '简体中文' },
  { code: 'en', label: 'English' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'th', label: 'ไทย' },
  { code: 'vi', label: 'Tiếng Việt' },
  { code: 'ms', label: 'Bahasa Melayu' },
  { code: 'la', label: 'Latina' },
];

const SLOGAN2: Record<string, string> = {
  'zh-TW': '每一位更生人，都是世界的一員！',
  'zh-CN': '每一位更生人，都是世界的一员！',
  'en': 'Every Restarter is still one of us.',
  'ja': 'すべての更生者は世界の一員です！',
  'ko': '모든 Restarter는 우리 중 한 명입니다!',
  'th': 'ทุกคนที่ถูกกำพฤติกรรมก็ยังเป็นหนึ่งของเรา!',
  'vi': 'Mỗi người được định hình đều là một thành viên của chúng tôi!',
  'ms': 'Setiap Restarter masih satu di antara kita!',
  'la': 'Omnis Restarter adhuc unus ex nobis est.',
};

const restarterRoleLeft: Record<string, string> = {
  'zh-TW': 'Restarter™ 是更生者的 副駕 / 合作人。',
  'zh-CN': 'Restarter™ 是更生者的 副驾 / 合作人。',
  'en': 'Restarter™ is a co-pilot/partner for Restarters.',
  'ja': 'Restarter™ は更生者の副操縦士・パートナーです。',
  'ko': 'Restarter™는 재생자의 부승무 또는 파트너입니다.',
  'th': 'Restarter™ เป็นคู่ควบคุมหรือพาร์ทเนอร์สำหรับ Restarters.',
  'vi': 'Restarter™ là phi công phụ hoặc đối tác cho Restarters.',
  'ms': 'Restarter™ adalah kopilot/pasukan untuk Restarters.',
  'la': 'Restarter™ est co-pilotus/socius pro Restarters.',
};

const restarterRoleRight: Record<string, string> = {
  'zh-TW': 'Restarter™ 是更生者的情緒管家 / 生產助手',
  'zh-CN': 'Restarter™ 是更生者的情绪管家 / 生产助手',
  'en': 'Restarter™ is an emotional steward/productivity assistant for Restarters.',
  'ja': 'Restarter™ は更生者の感情マネージャー・生産アシスタントです。',
  'ko': 'Restarter™는 재생자의 감정 관리자 및 생산 보조자입니다.',
  'th': 'Restarter™ เป็นผู้ดูแลอารมณ์และผู้ช่วยในการผลิตสำหรับ Restarters.',
  'vi': 'Restarter™ là người quản lý cảm xúc và người trợ giúp sản xuất cho Restarters.',
  'ms': 'Restarter™ adalah pengurus emosi / pembantu produktiviti untuk Restarters.',
  'la': 'Restarter™ est motus oeconomus/producentis adiutor pro Restarters.',
};

const INTEREST_OPTIONS: Record<string, string[]> = {
  'zh-TW': ['經濟','運動','閱讀','電影','旅遊','交友','唱歌','電商','做生意','電腦','AI','寵物','學技能','一個人安靜','其他'],
  'zh-CN': ['经济','运动','阅读','电影','旅游','交友','唱歌','电商','做生意','电脑','AI','宠物','学技能','一个人安静','其他'],
  'en': ['Economy','Sports','Reading','Movie','Travel','Friendship','Singing','E-commerce','Business','Computer','AI','Pets','Learning Skills','Quiet time alone','Other'],
  'ja': ['経済','スポーツ','読書','映画','旅行','友達','カラオケ','EC','ビジネス','パソコン','AI','ペット','スキル学習','一人で静かに過ごす','その他'],
  'ko': ['경제','스포츠','독서','영화','여행','친구 사귀기','노래 부르기','전자상거래','사업','컴퓨터','AI','애완동물','기술 배우기','혼자 조용히 있기','기타'],
  'th': ['เศรษฐกิจ','กีฬา','การอ่าน','ภาพยนตร์','การเดินทาง','มิตรภาพ','การร้องเพลง','อีคอมเมิร์ซ','ธุรกิจ','คอมพิวเตอร์','AI','สัตว์เลี้ยง','การเรียนรู้ทักษะ','เวลาเงียบๆคนเดียว','อื่นๆ'],
  'vi': ['Kinh tế','Thể thao','Đọc sách','Phim ảnh','Du lịch','Tình bạn','Ca hát','Thương mại điện tử','Kinh doanh','Máy tính','AI','Thú cưng','Học kỹ năng','Ở một mình yên tĩnh','Khác'],
  'ms': ['Ekonomi','Sukan','Membaca','Filem','Melancong','Persahabatan','Menyanyi','E-dagang','Perniagaan','Komputer','AI','Haiwan Peliharaan','Belajar Kemahiran','Masa sunyi bersendirian','Lain-lain'],
  'la': ['Oeconomia','Ludi','Lectio','Pellicula','Iter','Amicitia','Cantus','E-commercium','Negotium','Computatrum','AI','Animalia Domestica','Discere Artes','Tempus quietum solus','Aliud'],
};

const COUNTRY_OPTIONS: Record<string, string[]> = {
  'zh-TW': ['台灣','中國大陸','日本','韓國','馬來西亞','新加坡','印尼','越南','菲律賓','英國','法國','德國','美國','加拿大','非洲','歐洲','南美洲','中東','其他'],
  'zh-CN': ['台湾','中国大陆','日本','韩国','马来西亚','新加坡','印尼','越南','菲律宾','英国','法国','德国','美国','加拿大','非洲','欧洲','南美洲','中东','其他'],
  'en': ['Taiwan','China','Japan','Korea','Malaysia','Singapore','Indonesia','Vietnam','Philippines','UK','France','Germany','USA','Canada','Africa','Europe','South America','Middle East','Other'],
  'ja': ['台湾','中国','日本','韓国','マレーシア','シンガポール','インドネシア','ベトナム','フィリピン','イギリス','フランス','ドイツ','アメリカ','カナダ','アフリカ','ヨーロッパ','南アメリカ','中東','その他'],
  'ko': ['대만','중국','일본','한국','말레이시아','싱가포르','인도네시아','베트남','필리핀','영국','프랑스','독일','미국','캐나다','아프리카','유럽','남아메리카','중동','기타'],
  'th': ['ไต้หวัน','จีน','ญี่ปุ่น','เกาหลี','มาเลเซีย','สิงคโปร์','อินโดนีเซีย','เวียดนาม','ฟิลิปปินส์','สหราชอาณาจักร','ฝรั่งเศส','เยอรมนี','สหรัฐอเมริกา','แคนาดา','แอฟริกา','ยุโรป','อเมริกาใต้','ตะวันออกกลาง','อื่นๆ'],
  'vi': ['Đài Loan','Trung Quốc','Nhật Bản','Hàn Quốc','Malaysia','Singapore','Indonesia','Việt Nam','Philippines','Anh','Pháp','Đức','Mỹ','Canada','Châu Phi','Châu Âu','Nam Mỹ','Trung Đông','Khác'],
  'ms': ['Taiwan','China','Jepun','Korea','Malaysia','Singapura','Indonesia','Vietnam','Filipina','UK','Perancis','Jerman','AS','Kanada','Afrika','Eropah','Amerika Selatan','Timur Tengah','Lain-lain'],
  'la': ['Taivania','Sina','Iaponia','Corea','Malaisia','Singapura','Indonesia','Vietnamia','Philippinae','UK','Gallia','Germania','USA','Canada','Africa','Europa','America Meridionalis','Oriens Medius','Aliud'],
};

const EVENT_TYPE_OPTIONS: Record<string, string[]> = {
  'zh-TW': ["經濟事件", "毒品濫用", "暴力事件", "家暴加害", "家暴受害", "幫派背景", "詐欺相關", "竊盜前科", "性別/身體創傷", "未成年犯罪", "長期失業 / 社會邊緣", "其他"],
  'zh-CN': ["经济事件", "毒品滥用", "暴力事件", "家暴加害", "家暴受害", "帮派背景", "诈欺相关", "窃盗前科", "性别/身体创伤", "未成年犯罪", "长期失业 / 社会边缘", "其他"],
  'en': ["Economic Incident", "Drug Abuse", "Violent Incident", "Domestic Violence Perpetrator", "Domestic Violence Victim", "Gang Affiliation", "Fraud-related", "Theft Record", "Gender/Physical Trauma", "Juvenile Delinquency", "Long-term Unemployed / Socially Marginalized", "Other"],
  'ja': ["経済事件", "薬物乱用", "暴力事件", "DV加害", "DV被害", "ギャング組織所属", "詐欺関連", "窃盗前科", "ジェンダー・身体的トラウマ", "未成年犯罪", "長期失業・社会的疎外", "その他"],
  'ko': ["경제 사건", "약물 남용", "폭력 사건", "가정 폭력 가해자", "가정 폭력 피해자", "조직 폭력배 배경", "사기 관련", "절도 전과", "성별/신체적 트라우마", "미성년 범죄", "장기 실업/사회적 소외", "기타"],
  'th': ["เหตุการณ์ทางเศรษฐกิจ", "การใช้ยาเสพติด", "เหตุการณ์รุนแรง", "ผู้กระทำความรุนแรงในครอบครัว", "เหยื่อความรุนแรงในครอบครัว", "ประวัติแก๊ง", "เกี่ยวข้องกับการฉ้อโกง", "ประวัติการลักขโมย", "การบาดเจ็บทางเพศ/ร่างกาย", "การกระทำผิดของเยาวชน", "ว่างงานระยะยาว / ถูกกีดกันทางสังคม", "อื่นๆ"],
  'vi': ["Sự cố kinh tế", "Lạm dụng ma túy", "Vụ việc bạo lực", "Thủ phạm bạo lực gia đình", "Nạn nhân bạo lực gia đình", "Lý lịch băng đảng", "Liên quan đến gian lận", "Tiền án trộm cắp", "Tổn thương giới tính/thể chất", "Phạm pháp vị thành niên", "Thất nghiệp dài hạn / Bên lề xã hội", "Khác"],
  'ms': ["Insiden Ekonomi", "Penyalahgunaan Dadah", "Insiden Keganasan", "Pelaku Keganasan Rumah Tangga", "Mangsa Keganasan Rumah Tangga", "Latar Belakang Geng", "Berkaitan Penipuan", "Rekod Curi", "Trauma Jantina/Fizikal", "Kenakalan Remaja", "Pengangguran Jangka Panjang / Terpinggir Sosial", "Lain-lain"],
  'la': ["Casus Oeconomicus", "Abusus Medicamentorum", "Casus violentus", "Perpetrator Violentiae Domesticae", "Victima Violentiae Domesticae", "Consociatio Gregis", "Ad Fraudem Pertinens", "Furtum Record", "Trauma Genus/Corporale", "Delinquentia Iuvenilis", "Longum Tempus Inops / Socialiter Marginatus", "Aliud"],
};

const IMPROVEMENT_OPTIONS: Record<string, string[]> = {
  'zh-TW': ['人際','鬥志','習慣','工作','情緒','自律','其他'],
  'zh-CN': ['人际','斗志','习惯','工作','情绪','自律','其他'],
  'en': ['Interpersonal','Motivation','Habits','Work','Emotions','Self-discipline','Other'],
  'ja': ['人間関係','闘志','習慣','仕事','感情','自己規律','その他'],
  'ko': ['대인관계','투지','습관','업무','감정','자기관리','기타'],
  'th': ['ความสัมพันธ์ระหว่างบุคคล','แรงจูงใจ','นิสัย','การงาน','อารมณ์','การมีวินัยในตนเอง','อื่นๆ'],
  'vi': ['Quan hệ giữa các cá nhân','Ý chí chiến đấu','Thói quen','Công việc','Cảm xúc','Kỷ luật tự giác','Khác'],
  'ms': ['Antara peribadi','Semangat juang','Tabiat','Kerja','Emosi','Disiplin diri','Lain-lain'],
  'la': ['Interpersonalis','Animus','Consuetudines','Opus','Affectus','Disciplina sui','Aliud'],
};

const ageRanges = ["18-24", "25-29", "30-34", "35-39", "40-44", "45-49", "50-54", "55-59", "60-64", "65-69", "70+"];

function validateEmail(email: string) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email); }
function validatePassword(pw: string) { return /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/.test(pw); }
function validateNickname(nick: string) { return /^[\w\u4e00-\u9fa5]{2,16}$/.test(nick); }
function validateAge(age: string) { return ageRanges.includes(age); }

function renderRestarterRole(role: string) {
  if (!role) return null;
  const match = role.match(/^(Restarter™)(.*)$/);
  if (!match) return role;
  return (
    <span>
      <span style={{ color: '#fff', fontWeight: 700 }}>Restarter™</span>
      <span style={{ color: '#ffd700', fontWeight: 700 }}>{match[2]}</span>
    </span>
  );
}

type LangKey = keyof typeof TEXT;

function LoginModal({ t, setShowLogin, navigate }: { t: any, setShowLogin: (show: boolean) => void, navigate: any }) {
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await signInWithEmailAndPassword(auth, loginEmail, loginPassword);
      setShowLogin(false);
      navigate('/');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', background: 'rgba(0,0,0,0.6)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 200 }}>
      <div style={{ background: 'white', padding: 32, borderRadius: 16, width: '90%', maxWidth: 400, position: 'relative', boxShadow: '0 8px 32px #0000004d' }}>
        <button onClick={() => setShowLogin(false)} style={{ position: 'absolute', top: 8, right: 12, background: 'none', border: 'none', fontSize: 28, cursor: 'pointer', color: '#888' }}>&times;</button>
        <h2 style={{ textAlign: 'center', color: '#333', marginBottom: 24 }}>{t.login}</h2>
        {error && <p style={{ color: 'red', textAlign: 'center', marginBottom: '1rem' }}>{error}</p>}
        <form onSubmit={handleLogin}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <input type="email" placeholder={t.email} value={loginEmail} onChange={e => setLoginEmail(e.target.value)} className="reg-input" required />
            <input type="password" placeholder={t.password} value={loginPassword} onChange={e => setLoginPassword(e.target.value)} className="reg-input" required />
          </div>
          <button type="submit" style={{ width: '100%', marginTop: 24, background: 'linear-gradient(90deg, #6e8efb, #a777e3)', color: 'white', border: 'none', borderRadius: 8, padding: '14px 0', fontSize: 18, fontWeight: 700, cursor: 'pointer' }}>
            {t.login}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function RegisterPage() {
  const navigate = useNavigate();
  const [lang, setLang] = useState<LangKey>(() => (localStorage.getItem('lang') as LangKey) || 'zh-TW');
  useEffect(() => { localStorage.setItem('lang', lang); }, [lang]);
  const t = TEXT[lang];
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nickname, setNickname] = useState('');
  const [country, setCountry] = useState('');
  const [region, setRegion] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  const [avatarFile, setAvatarFile] = useState<File|null>(null);
  const [avatarUrl, setAvatarUrl] = useState<string>('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [interest, setInterest] = useState('');
  const [eventType, setEventType] = useState('');
  const [improvement, setImprovement] = useState('');
  const [showLogin, setShowLogin] = useState(false);

  useEffect(() => {
    const auth = getAuth(app);
    if (auth.currentUser) {
      navigate('/');
    }
  }, [navigate]);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!avatarFile) { setError(t.errorAvatar); return; }
    if (!gender) { setError(t.errorGender); return; }
    if (!validateEmail(email)) { setError(t.errorEmailFormat); return; }
    if (!validatePassword(password)) { setError(t.errorPasswordFormat); return; }
    if (!validateNickname(nickname)) { setError(t.errorNicknameFormat); return; }
    if (!age) { setError(t.errorAgeFormat); return; }
    if (!country) { setError(t.errorCountry); return; }
    if (!interest) { setError(t.errorInterest); return; }
    if (!eventType) { setError(t.errorEventType); return; }
    if (!improvement) { setError(t.errorImprovement); return; }
    
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(userCredential.user, { displayName: nickname });
      localStorage.removeItem('aiAvatar');
      localStorage.removeItem('avatarWelcomed');
      setLoading(false);
      navigate('/');
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && (file.type === 'image/jpeg' || file.type === 'image/png')) {
      setAvatarFile(file);
      setAvatarUrl(URL.createObjectURL(file));
    } else {
      setAvatarFile(null);
      setAvatarUrl('');
    }
  };

  return (
    <>
      {showLogin && <LoginModal t={t} setShowLogin={setShowLogin} navigate={navigate} />}
      <div style={{ position: 'relative' }}>
        <div style={{ position: 'fixed', top: -15, left: 36, zIndex: 101 }}>
          <img src="/ctx-logo.png" alt="Logo" style={{ width: 128, height: 128 }} />
        </div>
        <div style={{ minHeight: '100vh', background: `url('/city-blur.jpg') center/cover no-repeat`, position: 'relative', display: 'flex', flexDirection: 'column' }}>
          <div style={{ position: 'fixed', top: 24, left: '50%', transform: 'translateX(-50%)', zIndex: 100 }}>
            <span style={{ fontWeight: 900, fontSize: 28, color: '#ffd700', letterSpacing: 2, textShadow: '0 2px 8px #23294688', whiteSpace: 'nowrap', textAlign: 'center' }}>{SLOGAN2[lang]}</span>
          </div>
          <div style={{ position: 'fixed', top: 24, right: 36, zIndex: 100 }}>
            <select value={lang} onChange={e => setLang(e.target.value as LangKey)} style={{ padding: '6px 14px', borderRadius: 8, fontWeight: 600 }}>
              {LANGS.map(l => (
                <option key={l.code} value={l.code}>{l.label}</option>
              ))}
            </select>
          </div>
          <div style={{ display: 'flex', flex: 1, minHeight: '100vh', alignItems: 'stretch', justifyContent: 'center', width: '100%', marginTop: 60 }}>
            {/* Left Hero Text */}
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', background: 'rgba(60,40,20,0.18)', padding: '0 12px', minHeight: 'calc(100vh - 60px)', boxSizing: 'border-box', justifyContent: 'space-between' }}>
                <div style={{ position: 'relative', width: '100%', textAlign: 'center', paddingTop: 78 }}>
                    <div style={{ fontSize: 18, fontWeight: 700, textShadow: '0 2px 8px #23294688' }}>
                        {renderRestarterRole(restarterRoleLeft[lang])}
                    </div>
                </div>
                <img src="/left-hero.png" alt="left hero" style={{ width: 300, maxWidth: '98%', objectFit: 'contain' }} />
                <div style={{ paddingBottom: 80, textAlign: 'center' }}>
                    <div style={{ color: '#fff', fontWeight: 700, fontSize: 22, margin: '12px 0 8px' }}>
                      {t.heroLeftTop}<br/>
                      {t.heroLeftMain}<br/>
                      {t.heroLeftSub}
                    </div>
                    <div style={{ color: '#ffd700', fontWeight: 700, fontSize: 18 }}>{t.heroLeftYellow}</div>
                </div>
            </div>
            {/* Center Registration Form */}
            <div style={{ flex: '0 1 500px', display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '20px 0' }}>
              <form onSubmit={handleRegister} style={{ background: '#ffffffcc', borderRadius: 20, padding: '24px 32px', width: '100%', maxWidth: 500, boxShadow: '0 8px 32px #0000004d', position: 'relative' }}>
                <img src="/ctx-logo.png" alt="Logo" style={{ width: 100, height: 100, position: 'absolute', top: 5, left: 5, zIndex: 0, opacity: 1 }} />
                <div style={{position: 'relative', zIndex: 1}}>
                  <div style={{ width: '100%', textAlign: 'center', fontWeight: 900, fontSize: 26, color: '#ffd700', marginBottom: 8, textShadow: '0 2px 4px #00000055' }}>{t.formTopSlogan}</div>
                  <h2 style={{ textAlign: 'center', color: '#333', marginBottom: 16, fontSize: 28, fontWeight: 800 }}>{t.title}</h2>
                  {error && <p style={{ color: 'red', textAlign: 'center', marginBottom: '1rem' }}>{error}</p>}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-around', marginBottom: 16, background: '#f0f4f8', borderRadius: 12, padding: '8px 16px' }}>
                    <div style={{ textAlign: 'center' }}>
                      <label htmlFor="avatar-upload" style={{ cursor: 'pointer', display: 'block', position: 'relative', width: 80, height: 80 }}>
                        <div style={{ width: '100%', height: '100%', borderRadius: '50%', background: '#e0e0e0', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
                          {avatarUrl ? 
                            <img src={avatarUrl} alt="Avatar Preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : 
                            <span style={{ fontSize: 32 }}>👤</span>}
                        </div>
                        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'rgba(0,0,0,0.5)', color: 'white', fontSize: 12, padding: '2px 0', borderBottomLeftRadius: 40, borderBottomRightRadius: 40 }}>
                          {t.uploadAvatar}
                        </div>
                      </label>
                      <input id="avatar-upload" type="file" accept="image/jpeg, image/png" onChange={handleAvatarChange} style={{ display: 'none' }} />
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ marginBottom: 8, fontSize: 28 }}>
                        <span>👨</span><span>👩</span>
                      </div>
                      <div style={{ display: 'flex', gap: 12 }}>
                        <label style={{ cursor: 'pointer', fontSize: 14 }}><input type="radio" name="gender" value="male" checked={gender === 'male'} onChange={e => setGender(e.target.value)} style={{ marginRight: 4 }} />{t.male}</label>
                        <label style={{ cursor: 'pointer', fontSize: 14 }}><input type="radio" name="gender" value="female" checked={gender === 'female'} onChange={e => setGender(e.target.value)} style={{ marginRight: 4 }} />{t.female}</label>
                      </div>
                      <div style={{ fontSize: 12, color: '#666', marginTop: 4 }}>{t.genderRequired}</div>
                    </div>
                  </div>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
                    <input type="email" placeholder={t.email} value={email} onChange={e => setEmail(e.target.value)} style={{ gridColumn: '1 / -1' }} className="reg-input" required/>
                    <input type="password" placeholder={t.password} value={password} onChange={e => setPassword(e.target.value)} style={{ gridColumn: '1 / -1' }} className="reg-input" required/>
                    <input type="text" placeholder={t.nickname} value={nickname} onChange={e => setNickname(e.target.value)} className="reg-input" required/>
                    <select value={age} onChange={e => setAge(e.target.value)} className="reg-input" required>
                      <option value="">{t.selectAge}</option>
                      {ageRanges.map(a => <option key={a} value={a}>{a}</option>)}
                    </select>
                    <select value={country} onChange={e => setCountry(e.target.value)} className="reg-input" required>
                      <option value="">{t.country}</option>
                      {(COUNTRY_OPTIONS[lang] || []).map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                    <input type="text" placeholder={t.city} value={region} onChange={e => setRegion(e.target.value)} className="reg-input" />
                    <select value={interest} onChange={e => setInterest(e.target.value)} className="reg-input" required>
                      <option value="">{t.interest}</option>
                      {(INTEREST_OPTIONS[lang] || []).map(i => <option key={i} value={i}>{i}</option>)}
                    </select>
                    <select value={eventType} onChange={e => setEventType(e.target.value)} className="reg-input" required>
                      <option value="">{t.eventType}</option>
                      {(EVENT_TYPE_OPTIONS[lang] || []).map(e => <option key={e} value={e}>{e}</option>)}
                    </select>
                    <select value={improvement} onChange={e => setImprovement(e.target.value)} className="reg-input" required style={{ gridColumn: '1 / -1' }}>
                      <option value="">{t.whatToImprove}</option>
                      {(IMPROVEMENT_OPTIONS[lang] || []).map(i => <option key={i} value={i}>{i}</option>)}
                    </select>
                  </div>

                  <button type="submit" disabled={loading} style={{ width: '100%', marginTop: 20, background: 'linear-gradient(90deg, #6e8efb, #a777e3)', color: 'white', border: 'none', borderRadius: 8, padding: '12px 0', fontSize: 18, fontWeight: 700, cursor: 'pointer' }}>
                    {loading ? t.registering : t.register}
                  </button>
                  <button type="button" onClick={() => setShowLogin(true)} style={{ width: '100%', marginTop: 10, background: 'linear-gradient(90deg, #89f7fe, #66a6ff)', color: 'white', border: 'none', borderRadius: 8, padding: '10px 0', fontSize: 16, fontWeight: 700, cursor: 'pointer' }}>
                    {t.login} 🔑
                  </button>
                  <button type="button" onClick={() => navigate('/terms')} style={{ background: 'none', border: 'none', color: '#666', textDecoration: 'underline', cursor: 'pointer', marginTop: 12, fontSize: 14, display: 'block', width: '100%', textAlign: 'center' }}>
                    {t.terms}
                  </button>
                </div>
              </form>
            </div>
            {/* Right Hero Text */}
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', background: 'rgba(60,40,20,0.18)', padding: '0 12px', minHeight: 'calc(100vh - 60px)', boxSizing: 'border-box', justifyContent: 'space-between' }}>
                <div style={{ position: 'relative', width: '100%', textAlign: 'center', paddingTop: 78 }}>
                    <div style={{ fontSize: 18, fontWeight: 700, textShadow: '0 2px 8px #23294688' }}>
                        {renderRestarterRole(restarterRoleRight[lang])}
                    </div>
                </div>
                <img src="/right-hero.png" alt="right hero" style={{ width: 280, maxWidth: '98%', objectFit: 'contain' }} />
                <div style={{ paddingBottom: 80, textAlign: 'center' }}>
                    <div style={{ color: '#fff', fontWeight: 700, fontSize: 22, margin: '12px 0 8px' }}>{t.heroRightMain}</div>
                    <div style={{ color: '#ffd700', fontWeight: 700, fontSize: 18 }}>{t.heroRightYellow}</div>
                </div>
            </div>
          </div>
          <div style={{ position: 'fixed', bottom: 10, left: 36, color: '#fff', textShadow: '0 1px 2px #000', fontSize: 14, zIndex: 10 }}>
            CTX Goodlife Copyright 2025
          </div>
        </div>
      </div>
    </>
  );
}