import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function TermsPage() {
  const navigate = useNavigate();

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#111827', color: 'white', padding: '2rem', display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: '1 0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <img src="/statement.png" alt="Logo" style={{ width: '120px' }} />
        </div>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <button
            onClick={() => navigate('/')}
            style={{ 
              marginBottom: '2rem', 
              backgroundColor: '#374151', 
              color: 'white', 
              fontWeight: 'bold', 
              padding: '0.5rem 1rem', 
              borderRadius: '0.375rem',
              border: 'none',
              cursor: 'pointer'
            }}
          >
            &larr; 返回
          </button>
          <h1 style={{ fontSize: '1.75rem', fontWeight: 'bold', marginBottom: '2rem', textAlign: 'center' }}>Restarter™ 使用條款與更生人聲明</h1>

          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginTop: '2rem', marginBottom: '1rem', borderBottom: '2px solid #374151', paddingBottom: '0.5rem' }}>一、平台理念聲明</h2>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>Restarter™ 是一個致力於陪伴更生人重建社交、情緒與生活信心的AI應用平台。本平台旨在透過情緒引導、角色模擬與任務挑戰，協助使用者排解負面情緒、建立目標、重拾掌控感。</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>我們深知，每一位更生者都值得被尊重與重新認識。你曾經犯錯，但這裡不會再用標籤定義你。</p>

          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginTop: '2rem', marginBottom: '1rem', borderBottom: '2px solid #374151', paddingBottom: '0.5rem' }}>二、用戶身分與行為規範</h2>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>本平台歡迎曾經服刑、羈押、戒癮、感化、接受司法保護、或遭受社會排斥之個人註冊使用。</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>為確保社群安全，禁止：</p>
          <ul style={{ listStyleType: 'disc', paddingLeft: '2rem', marginBottom: '1rem', fontSize: '0.9rem' }}>
            <li>假冒他人身分</li>
            <li>散佈暴力、歧視、仇恨言論</li>
            <li>上傳非法圖片或語音</li>
          </ul>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>使用本平台代表你同意尊重自己與他人，並承諾不再重蹈過往行為。</p>

          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginTop: '2rem', marginBottom: '1rem', borderBottom: '2px solid #374151', paddingBottom: '0.5rem' }}>三、隱私與資料使用</h2>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>所有註冊資料僅用於：</p>
          <ul style={{ listStyleType: 'disc', paddingLeft: '2rem', marginBottom: '1rem', fontSize: '0.9rem' }}>
            <li>配對模組運作</li>
            <li>任務進度追蹤</li>
            <li>個人情緒模型優化</li>
          </ul>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>我們不會將使用者資料提供給任何第三方，除非依法要求。</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>所有對話記錄、生成內容將匿名化儲存，用於改進 AI 系統。</p>

          <h3 style={{ fontSize: '1.1rem', fontWeight: 'bold', marginTop: '1.5rem', marginBottom: '1rem' }}>資料保護與使用方式聲明</h3>
          <ol style={{ listStyleType: 'decimal', paddingLeft: '2rem', marginBottom: '1rem', fontSize: '0.9rem', lineHeight: '1.6' }}>
            <li>
              Restarter™ 所蒐集的所有註冊資料，僅用於平台內部使用，包括：
              <ul style={{ listStyleType: 'disc', paddingLeft: '2rem', marginTop: '0.5rem' }}>
                <li>AI 任務系統推薦與個性化設定</li>
                <li>用戶成長歷程追蹤</li>
                <li>系統安全與風險控管</li>
              </ul>
            </li>
            <li style={{ marginTop: '0.5rem' }}>我們不會將個資提供給任何第三方（包括政府與企業），除非依法正式請求。</li>
            <li style={{ marginTop: '0.5rem' }}>使用者可隨時申請刪除個人帳號與歷史資料，刪除後無法回復。</li>
            <li style={{ marginTop: '0.5rem' }}>所有與更生背景相關欄位，僅用於 AI 模型分類邏輯，<strong>不會對外公開或做任何社交曝光</strong>。</li>
            <li style={{ marginTop: '0.5rem' }}>若您使用匿名暱稱、虛擬頭像，本平台將尊重您的身分選擇。</li>
            <li style={{ marginTop: '0.5rem' }}>所有對話與資料紀錄皆經過匿名化加密處理，保障您的重啟之路安全無虞。</li>
          </ol>

          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginTop: '2rem', marginBottom: '1rem', borderBottom: '2px solid #374151', paddingBottom: '0.5rem' }}>四、AI回應與使用限制</h2>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>本平台使用 GPT 技術進行語言模擬、陪聊與任務回應，內容僅供參考，不代表醫療或法律建議。</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>若你有自殺傾向、嚴重情緒困擾，請立即聯繫真人輔導資源（如 1925安心專線）。</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>我們不保證 AI 回應皆為中立或無偏見，如有任何不適，請立即回報。</p>

          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginTop: '2rem', marginBottom: '1rem', borderBottom: '2px solid #374151', paddingBottom: '0.5rem' }}>五、風險與免責聲明</h2>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>本平台不對用戶個人行為後果負任何法律責任。</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>若因用戶自行散布個資、照片、語音而導致風險，本平台不負擔保責任。</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>使用平台即代表你理解並接受以上風險。</p>

          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginTop: '2rem', marginBottom: '1rem', borderBottom: '2px solid #374151', paddingBottom: '0.5rem' }}>六、鼓勵與承諾語</h2>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>「這裡沒有神，但我們相信人可以再次選擇做對的事。」</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>「你不是僅僅被原諒，而是被允許重新開始。」</p>
          <p style={{ marginBottom: '1rem', lineHeight: '1.6', fontSize: '0.9rem' }}>「Restarter™  是你的第二人生登錄點，現在，是重新啟動的時候了。」</p>
        </div>
      </div>
      <footer style={{ flexShrink: 0, fontSize: '0.75rem', color: '#9CA3AF', paddingTop: '1rem' }}>
        【CTX Goodlife Copyright 2025】
      </footer>
    </div>
  );
} 