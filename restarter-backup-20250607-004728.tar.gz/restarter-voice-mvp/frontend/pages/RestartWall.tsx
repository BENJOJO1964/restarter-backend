import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { formatWithTone } from '../utils/toneFormatter';
import type { Tone, Quote } from '../../shared/types';

const demoTones: Tone[] = [
  { id: 'gentle', name: '溫柔', description: '溫柔、體貼、安撫人心', stylePrompt: '請用溫柔、體貼的語氣回應。' },
  { id: 'hopeful', name: '希望', description: '充滿希望、鼓勵、正向', stylePrompt: '請用充滿希望、鼓勵的語氣回應。' },
];

interface Message {
  id: string;
  text: string;
  aiReply: string;
  toneId: string;
  createdAt: string;
}

export default function RestartWall() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [selectedTone, setSelectedTone] = useState<Tone>(demoTones[0]);
  const [loading, setLoading] = useState(false);

  // 假 AI 回覆
  const fakeAIReply = (text: string, tone: Tone) => `${formatWithTone('AI安慰：' + text, tone.name)}`;

  const handleSend = async () => {
    if (!input.trim()) return;
    setLoading(true);
    const userMsg: Message = {
      id: Date.now().toString(),
      text: input,
      aiReply: '',
      toneId: selectedTone.id,
      createdAt: new Date().toISOString(),
    };
    setMessages([userMsg, ...messages]);
    setInput('');
    // 模擬 AI 回覆
    setTimeout(() => {
      setMessages(prev => prev.map(m => m.id === userMsg.id ? { ...m, aiReply: fakeAIReply(m.text, selectedTone) } : m));
      setLoading(false);
    }, 1200);
  };

  return (
    <div className="modern-bg" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div className="modern-container" style={{ maxWidth: 600, width: '100%', margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
          <button onClick={() => navigate('/')} style={{ background: 'none', border: 'none', color: '#6c63ff', fontWeight: 700, fontSize: 18, cursor: 'pointer', marginRight: 12 }}>← 返回首頁</button>
          <h2 className="modern-title" style={{ fontSize: '2rem', margin: 0, flex: 1, textAlign: 'center' }}>情緒牆 Restart Wall</h2>
        </div>
        <div className="tone-list" style={{ marginBottom: 18 }}>
          {demoTones.map(tone => (
            <div
              key={tone.id}
              className={`tone-card${selectedTone.id === tone.id ? ' selected' : ''}`}
              onClick={() => setSelectedTone(tone)}
            >
              <div className="tone-name">{tone.name}</div>
              <div className="tone-desc">{tone.description}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 12, marginBottom: 18 }}>
          <input
            className="quote-card"
            style={{ flex: 1, fontSize: 18, padding: '12px 16px', border: 'none', outline: 'none', background: '#232946', color: '#fff' }}
            placeholder="說出你的心聲... (語音輸入可後續補上)"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            disabled={loading}
          />
          <button
            className="tone-card selected"
            style={{ fontSize: 18, padding: '12px 24px' }}
            onClick={handleSend}
            disabled={loading}
          >
            {loading ? '發送中...' : '發送'}
          </button>
        </div>
        <div className="quote-list">
          {messages.length === 0 && <div style={{ color: '#b3b8d6', textAlign: 'center', marginTop: 32 }}>還沒有留言，快來發表你的心聲吧！</div>}
          {messages.map(msg => (
            <div key={msg.id} className="quote-card">
              <div className="quote-text">{msg.text}</div>
              <div className="quote-tone">({msg.toneId})</div>
              {msg.aiReply && <div className="quote-tone-style">{msg.aiReply}</div>}
              <div style={{ fontSize: 12, color: '#b3b8d6', marginTop: 6 }}>{new Date(msg.createdAt).toLocaleString()}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
} 