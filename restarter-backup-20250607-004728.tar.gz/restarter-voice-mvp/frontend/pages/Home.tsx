import React, { useState, useRef, useLayoutEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const LANGS = [
  { code: 'zh-TW', label: '繁中' },
  { code: 'zh-CN', label: '简中' },
  { code: 'en', label: 'EN' },
  { code: 'ja', label: '日本語' },
];

const TEXT = {
  'zh-TW': {
    slogan: ['站出來', '不是只有你一個人！'],
    desc: 'Restarter™你的情緒夥伴，傾聽你的聲音、用聲音.文字回應你，支持你表白，陪你被好好聽見。',
    wall: '進入情緒牆（Restart Wall）',
    voice: '即時語音輸入',
    ai: 'AI 風格回覆',
    tts: '擬真語音輸出',
    chat: '來聊天吧！',
  },
  'zh-CN': {
    slogan: ['站出来', '不是只有你一个人！'],
    desc: 'Restarter™你的情绪伙伴，倾听你的声音、用声音.文字回应你，支持你表白，陪你被好好听见。',
    wall: '进入情绪墙（Restart Wall）',
    voice: '即时语音输入',
    ai: 'AI 风格回复',
    tts: '拟真语音输出',
    chat: '来聊天吧！',
  },
  'en': {
    slogan: ['Speak up', 'you are not alone!'],
    desc: 'Restarter™ is your emotional companion, listening to your voice and responding with voice or text, supporting your expression and making you truly heard.',
    wall: 'Enter Restart Wall',
    voice: 'Voice Input',
    ai: 'AI Style Reply',
    tts: 'Realistic TTS',
    chat: "Let's Chat!",
  },
  'ja': {
    slogan: ['声を上げて', '一人じゃないよ！'],
    desc: 'Restarter™はあなたの感情パートナー。あなたの声に耳を傾け、声や文字で応え、あなたの気持ちを支え、しっかり受け止めます。',
    wall: '感情ウォールへ',
    voice: '音声入力',
    ai: 'AIスタイル返信',
    tts: 'リアルTTS',
    chat: '話しましょう！',
  },
};

export default function Home() {
  const navigate = useNavigate();
  const [lang, setLang] = useState('zh-TW');
  const t = TEXT[lang as keyof typeof TEXT];
  const featureBtnsRef = useRef<HTMLDivElement>(null);
  const chatBtnRef = useRef<HTMLButtonElement>(null);
  const [chatBtnMargin, setChatBtnMargin] = useState(0);

  useLayoutEffect(() => {
    if (featureBtnsRef.current && chatBtnRef.current) {
      const featureTop = featureBtnsRef.current.getBoundingClientRect().top;
      const chatBtnTop = chatBtnRef.current.getBoundingClientRect().top;
      const featureHeight = featureBtnsRef.current.getBoundingClientRect().height;
      const chatBtnHeight = chatBtnRef.current.getBoundingClientRect().height;
      setChatBtnMargin((featureTop + featureHeight) - (chatBtnTop + chatBtnHeight));
    }
  }, [lang]);

  const handleFeature = (type: string) => {
    if (type === 'voice') {
      navigate('/voice');
    } else if (type === 'ai') {
      alert(t.ai + ' 體驗即將開放，敬請期待！');
    } else if (type === 'tts') {
      alert(t.tts + ' 體驗即將開放，敬請期待！');
    } else if (type === 'chat') {
      navigate('/chat');
    }
  };
  return (
    <div className="modern-bg home-flex-root">
      {/* LOGO+標語固定左上角 */}
      <div className="fixed-logo-box" style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <img src="/ctx-logo.png" className="fixed-logo-img" style={{ marginBottom: 0 }} />
        <div className="fixed-logo-slogan" style={{ marginLeft: 8, whiteSpace: 'nowrap' }}>
          {t.slogan[0]}...{t.slogan[1]}
        </div>
      </div>
      {/* 左側：麥克風主題圖+聊天按鈕，與右側等高 */}
      <div className="home-left-col left-relative">
        <div className="column-content" style={{ justifyContent: 'flex-start', alignItems: 'center', height: '100%', paddingTop: 48 }}>
          <img src="/hero-mic.jpg" className="home-mic-img" style={{ marginBottom: 0, height: 'calc(100vh - 180px)', maxHeight: 520, minHeight: 320, width: '100%', objectFit: 'cover' }} />
          <button
            ref={chatBtnRef}
            className="feature-btn home-chat-btn"
            style={{ height: 64, marginTop: 0, marginBottom: 0, position: 'relative', top: '-32px', gap: 4 }}
            onClick={() => handleFeature('chat')}
          >
            <span role="img" aria-label="chat" style={{ marginRight: 2, fontSize: 22 }}>💬</span>
            <span className="home-chat-btn-text">{t.chat}</span>
          </button>
        </div>
      </div>
      {/* 右側：主內容 */}
      <div className="home-right modern-container" style={{ maxWidth: 520, textAlign: 'center' }}>
        <div className="column-content">
          <div className="lang-switch">
            <select className="lang-select" value={lang} onChange={e => setLang(e.target.value)}>
              {LANGS.map(l => (
                <option key={l.code} value={l.code}>{l.label}</option>
              ))}
            </select>
          </div>
          <h1 className="modern-title" style={{ fontSize: '2.8rem', marginBottom: 16 }}>Restart Voice Companion</h1>
          <p style={{ fontSize: '1.2rem', color: '#b3b8d6', marginBottom: 32, whiteSpace: 'pre-line' }}>{t.desc}</p>
          <button
            className="tone-card selected"
            style={{ fontSize: '1.2rem', padding: '18px 36px', marginBottom: 18 }}
            onClick={() => navigate('/wall')}
          >
            {t.wall}
          </button>
          <div className="feature-btns" ref={featureBtnsRef} style={{ marginTop: '64px' }}>
            <button className="feature-btn" onClick={() => handleFeature('voice')}><span role="img" aria-label="mic">🎤</span> {t.voice}</button>
            <button className="feature-btn" onClick={() => handleFeature('ai')}><span role="img" aria-label="ai">🤖</span> {t.ai}</button>
            <button className="feature-btn" onClick={() => handleFeature('tts')}><span role="img" aria-label="tts">🔊</span> {t.tts}</button>
          </div>
        </div>
      </div>
    </div>
  );
} 