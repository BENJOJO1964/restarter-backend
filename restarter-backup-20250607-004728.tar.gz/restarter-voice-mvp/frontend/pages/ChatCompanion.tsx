import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import VirtualAvatar from '../components/VirtualAvatar';
import { generateResponse } from '../lib/ai/generateResponse';
import { speak } from '../lib/ai/speak';
import { generateTalkingFace } from '../lib/ai/talkingFace';

interface ChatMsg {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  status?: 'streaming' | 'done';
}

export default function ChatCompanion() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState('');
  const [aiStreaming, setAIStreaming] = useState(false);
  const aiTimeout = useRef<number|null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [showInput, setShowInput] = useState(false);
  const [recording, setRecording] = useState(false);
  const [aiAvatar, setAiAvatar] = useState<string>('');
  const [showAvatarSelect, setShowAvatarSelect] = useState(false);
  const AVATAR_LIST = [
    ...[...Array(10)].map((_, i) => `/avatars/male${i+1}.jpg`),
    ...[...Array(10)].map((_, i) => `/avatars/female${i+1}.jpg`),
  ];
  const lang = (navigator.language || 'zh-TW').startsWith('zh-CN') ? 'zh-CN' : (navigator.language.startsWith('ja') ? 'ja' : (navigator.language.startsWith('en') ? 'en' : 'zh-TW'));
  const AVATAR_TITLE = {
    'zh-TW': '選我做你的朋友',
    'zh-CN': '选我做你的朋友',
    'en': 'Pick Me as Your Friend',
    'ja': '友達に選んでね',
  };
  useEffect(() => {
    const saved = localStorage.getItem('aiAvatar');
    if (saved) {
      setAiAvatar(saved);
    } else {
      setShowAvatarSelect(true);
    }
  }, []);
  const handleSelectAvatar = (url: string) => {
    setAiAvatar(url);
    localStorage.setItem('aiAvatar', url);
    setShowAvatarSelect(false);
  };

  // 模擬 AI 回覆（可被打斷）
  const fakeAIReply = (userText: string) => {
    setAIStreaming(true);
    const aiMsg: ChatMsg = {
      id: Date.now().toString(),
      text: '',
      sender: 'ai',
      status: 'streaming',
    };
    setMessages(prev => [...prev, aiMsg]);
    let idx = 0;
    const reply = `AI陪聊：我明白你的意思，「${userText}」，讓我再多聽你說說...`;
    aiTimeout.current = setInterval(() => {
      idx++;
      setMessages(prev => prev.map(m => m.id === aiMsg.id ? { ...m, text: reply.slice(0, idx) } : m));
      if (idx >= reply.length) {
        clearInterval(aiTimeout.current!);
        setMessages(prev => prev.map(m => m.id === aiMsg.id ? { ...m, status: 'done' } : m));
        setAIStreaming(false);
      }
    }, 40);
  };

  // 用戶送出訊息
  const handleSend = async () => {
    if (!input.trim()) return;
    // 若AI正在回覆，立即打斷
    if (aiStreaming && aiTimeout.current) {
      clearInterval(aiTimeout.current);
      setMessages(prev => prev.filter(m => m.sender !== 'ai' || m.status === 'done'));
      setAIStreaming(false);
    }
    const userMsg: ChatMsg = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
    };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setTimeout(() => fakeAIReply(userMsg.text), 400);
    // AI 虛擬人回應
    setIsSpeaking(true);
    const openaiKey = process.env.REACT_APP_OPENAI_API_KEY || '';
    const playhtKey = process.env.REACT_APP_PLAYHT_API_KEY || '';
    const didKey = process.env.REACT_APP_DID_API_KEY || '';
    const aiText = await generateResponse([
      { role: 'system', content: '你是一個溫暖、善解人意的虛擬人，請用鼓勵、正向語氣回應。' },
      { role: 'user', content: input },
    ], openaiKey);
    const ttsUrl = await speak(aiText, aiAvatar.includes('female') ? 'female' : 'male', playhtKey);
    setAvatarAudio(ttsUrl);
    const videoUrl = await generateTalkingFace({
      imageUrl: aiAvatar,
      audioUrl: ttsUrl,
      text: aiText,
      apiKey: didKey,
    });
    setAvatarVideo(videoUrl);
    setIsSpeaking(false);
  };

  return (
    <div className="modern-bg" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div className="modern-container" style={{ maxWidth: 540, width: '100%', margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
          <button onClick={() => navigate('/')} style={{ background: 'none', border: 'none', color: '#6c63ff', fontWeight: 700, fontSize: 18, cursor: 'pointer', marginRight: 12 }}>← 返回首頁</button>
          <h2 className="modern-title" style={{ fontSize: '2rem', margin: 0, flex: 1, textAlign: 'center' }}>AI 陪聊</h2>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 24 }}>
          <div style={{ position: 'relative', width: 160, height: 160, marginBottom: 8 }}>
            {avatarVideo ? (
              <video src={avatarVideo} width={160} height={160} autoPlay muted loop style={{ borderRadius: '50%', objectFit: 'cover' }} />
            ) : (
              aiAvatar ? <img src={aiAvatar} width={160} height={160} style={{ borderRadius: '50%', objectFit: 'cover', filter: isSpeaking ? 'brightness(1.1)' : 'none' }} alt="avatar" /> : null
            )}
          </div>
          {avatarAudio && (
            <audio src={avatarAudio} autoPlay />
          )}
        </div>
        {/* AI頭像選擇彈窗 */}
        {showAvatarSelect && (
          <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.18)', zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ background: '#fff', borderRadius: 24, padding: 32, minWidth: 320, maxWidth: 420, boxShadow: '0 4px 24px #0002', textAlign: 'center' }}>
              <div style={{ fontWeight: 700, color: '#6B4F27', fontSize: 22, marginBottom: 18 }}>{AVATAR_TITLE[lang]}</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, justifyContent: 'center' }}>
                {AVATAR_LIST.map((url, i) => (
                  <img key={url} src={url} alt={url} style={{ width: 64, height: 64, borderRadius: '50%', objectFit: 'cover', border: '2px solid #bbb', background: '#eee', cursor: 'pointer', boxShadow: aiAvatar === url ? '0 0 0 3px #6B5BFF' : undefined }} onClick={() => handleSelectAvatar(url)} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div className="quote-list" style={{ minHeight: 240, marginBottom: 18, background: 'rgba(35,41,70,0.7)', borderRadius: 16, padding: 12 }}>
          {messages.length === 0 && <div style={{ color: '#b3b8d6', textAlign: 'center', marginTop: 32 }}>開始與 AI 陪聊吧！</div>}
          {messages.map(msg => (
            <div key={msg.id} className="quote-card" style={{ background: msg.sender === 'user' ? 'linear-gradient(120deg, #6c63ff 60%, #232946 100%)' : undefined, alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start', color: msg.sender === 'user' ? '#fff' : undefined }}>
              <div className="quote-text">{msg.text}</div>
              <div className="quote-tone" style={{ color: msg.sender === 'user' ? '#b3b8d6' : '#6c63ff' }}>{msg.sender === 'user' ? '你' : 'AI'}</div>
              {msg.status === 'streaming' && <span style={{ color: '#6c63ff', fontSize: 12 }}>AI 回覆中...</span>}
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 32, justifyContent: 'center' }}>
          <button
            style={{
              width: 80,
              height: 80,
              borderRadius: '50%',
              background: recording ? 'linear-gradient(135deg, #ff5e3a 60%, #ffb47b 100%)' : 'linear-gradient(135deg, #6c63ff 60%, #23c6e6 100%)',
              color: '#fff',
              border: 'none',
              boxShadow: '0 2px 12px #23294633',
              fontSize: 36,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              marginBottom: 12,
              transition: 'background 0.2s',
            }}
            onClick={() => {
              if (!recording) {
                setShowInput(true);
                setRecording(true);
                setTimeout(() => inputRef.current?.focus(), 100);
              } else {
                setRecording(false);
                setShowInput(false);
                setInput('');
              }
            }}
          >
            {recording ? <span style={{fontSize: 38}}>■</span> : <span role="img" aria-label="mic">🎤</span>}
          </button>
          {!showInput && !recording && (
            <div style={{ color: '#b3b8d6', fontSize: 18, marginBottom: 8 }}>按一下開始聊天吧...</div>
          )}
          {showInput && (
            <input
              ref={inputRef}
              className="quote-card"
              style={{ fontSize: 20, padding: '18px 20px', width: 320, textAlign: 'center', margin: '0 auto' }}
              placeholder="請輸入訊息..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
              disabled={aiStreaming && !input.trim()}
              autoFocus
            />
          )}
        </div>
        {aiStreaming && <div style={{ color: '#6c63ff', marginTop: 10, textAlign: 'center' }}>AI 正在回覆中，輸入新訊息可立即打斷</div>}
      </div>
    </div>
  );
} 