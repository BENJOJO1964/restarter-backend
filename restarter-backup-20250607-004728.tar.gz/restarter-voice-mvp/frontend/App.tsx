// App.tsx - Restart Voice MVP 入口
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import Home from './pages/Home';
import RestartWall from './pages/RestartWall';
import ChatCompanion from './pages/ChatCompanion';
import RegisterPage from './pages/RegisterPage';
import './modern.css';
import app from './src/firebaseConfig';
import { getAuth, onAuthStateChanged } from 'firebase/auth';

function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const auth = getAuth(app);
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsub();
  }, []);
  if (loading) return <div style={{color:'#fff',textAlign:'center',marginTop:80}}>載入中...</div>;
  return (
    <BrowserRouter>
      <Routes>
        {!user && <Route path="*" element={<RegisterPage onRegister={() => window.location.reload()} />} />}
        {user && <Route path="/" element={<Home />} />}
        {user && <Route path="/wall" element={<RestartWall />} />}
        {user && <Route path="/chat" element={<ChatCompanion />} />}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
