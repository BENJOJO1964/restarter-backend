// gpt.js - GPT-4 對話服務
// TODO: 串接 OpenAI GPT-4，支援流式回覆

async function chatWithGPT(prompt) {
  // stub: 假回傳
  return `AI回覆（假資料）：${prompt}`;
}

module.exports = { chatWithGPT };
